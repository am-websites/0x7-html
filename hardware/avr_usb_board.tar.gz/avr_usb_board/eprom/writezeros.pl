#!/usr/bin/perl

use Time::HiRes qw( usleep);

$file="/dev/ttyUSB0";
$epromfile=$ARGV[0];
$/=' ';

open(FILE,"+<",$file) || die "ERROR: can't open $file";
printf(FILE "zoh\n");
printf(FILE "zih\n");
printf(FILE "e0\n");
$count=0;
for($count=0;$count<32768;$count++) {
	print(FILE "ew00\n");
	usleep(200);
	print(FILE "ei\n");
	usleep(100);
	if ($count%1000==0) {
		print "wrote $count bytes\n";
	}
}
print("\nwrote $count bytes\n");
close(FILE);
