#!/usr/bin/perl

use Time::HiRes qw( usleep);

$file="/dev/ttyUSB0";
$epromfile=$ARGV[0];
$/=' ';

open(FILE,"+<",$file) || die "ERROR: can't open $file";
open(EPROMFILE,"<",$epromfile) || die "ERROR: can't open $epromfile";
printf(FILE "zoh\n");
printf(FILE "zih\n");
printf(FILE "e0\n");
$count=0;

while (read(EPROMFILE,$byte,1)!=0) {
	if ($count>32768) {die "EPROM full";}
	$errorcount=0;
	$hexbyte=sprintf("%.2X",$byte);
	do {
		printf(FILE "ew".$hexbyte."\n");
		usleep(200);

		$verify=$hexbyte;
		
		#printf(FILE "ei\n");
		#usleep(100);
		#$verify=<FILE>;
		#if ($errorcount>5) {
		#	die "Error writing byte $count";
		#}
		$errorcount++;
	} while ($verify!=$hexbyte);
	$count++;
	if ($count%100==0) {
		print "wrote $count bytes\n";
	}
	
}
print("\nwrote $count bytes\n");
close(FILE);
close(EPROMFILE);
