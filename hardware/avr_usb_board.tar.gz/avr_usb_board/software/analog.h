/*	C include file for analog conversion
	Target:    any AVR device
	Copyright: GPL
*/

#ifndef ANALOG_H
#define ANALOG_H

#define ANALOG_PRECISION_SLOW	0
#define ANALOG_PRECISION_FAST	1

#define ANALOG_REFERENCE_VCC 	0
#define ANALOG_REFERENCE_INTERNAL	1

/* return analog value of a given channel. You must enable interrupt with
* * sei() in the main program */
extern int convertanalog(unsigned char channel);
extern uint16_t convertanalogextended(uint8_t admux);
extern void initanalog(uint8_t num_channels, uint8_t analog_reference, uint8_t analog_precision);
#endif /* ANALOG_H */
