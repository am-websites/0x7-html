/*	
Author: Guido Socher, Copyright: GPL 
Adjusted for avrlibc 1.04 and ATMega32 by Andreas M�ller
Clock frequency     : 8,000000 MHz
*/

#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include "analog.h"


volatile static unsigned char analog_busy; 
volatile static int analog_result; 

/* the following function will be called when analog conversion is done */
SIGNAL(SIG_ADC) {
	unsigned char adlow,adhigh;
	adlow=ADCL; /* read low first !! */
	adhigh=ADCH; /* read low first !! */
	analog_result=(adhigh<<8)|(adlow&0xFF);
	analog_busy=0;
}

void initanalog(uint8_t num_channels, uint8_t analog_reference, uint8_t analog_precision) {
	/*
	ADC INPUT Pins must be configured as input without pull-up; output pins of port A must not change during conversion
	*/
	uint8_t i;
	
	for(i=0;i<num_channels;i++) {
		DDRA&=~_BV(i);
		PORTA&=~_BV(i);
	}
		
        /* enable analog to digital conversion in single run mode
        *  without noise canceler function. See datasheet of at90s4433 page 55 
        * We set ADPS2 and ADPS0 to have a clock division factor of 32.
        * This is needed to stay in the recommended range of 50-200kHz 
        * ADEN: Analog Digital Converter Enable
        * ADIE: ADC Interrupt Enable
        * ADIF: ADC Interrupt Flag
        * ADCSR: ADC Control and Status Register
        * ADPS2..ADPS0: ADC Prescaler Select Bits
        */

	/* analog comparator multiplexer enable */
	SFIOR|=_BV(ACME);
	
	/* enable analog interrupt */
	//ACSR|=_BV(ACIE);
	
	/* AD Enable, AD Interrupt Enable, clear Interrupt Flag, set prescaler to  64 (ADC clock frequency  needs to be between 50kHz and 200 kHz) */

	ADCSRA|=_BV(ADEN)|_BV(ADIE)|_BV(ADIF)|_BV(ADPS2)|_BV(ADPS1);
	
	
	if (analog_reference==ANALOG_REFERENCE_VCC) {
		/* ADMUX: REFS1=0 REFS0=1 -> AVCC as Reference Voltage */
		ADMUX&=~_BV(REFS1); ADMUX|=_BV(REFS0);
	} else {
		/* ADMUX: REFS1=1 REFS0=1 -> internal 2.56 as Reference Voltage */
		ADMUX|=_BV(REFS0)|_BV(REFS1);
	}
}

/* return analog value of a given channel. You must enable interrupt with
* sei() in the main program */
int convertanalog(uint8_t channel) 
{	
	analog_busy=1;
		
	/* select channel (only lower 3 bits) */
	/* also possible: differential input and gain */
	ADMUX |= channel&0x07; ADMUX &= ~((~channel)&0x07);
	
	/*  start conversion */
	ADCSRA |= _BV(ADSC);
	while(analog_busy); /* wait for result */
	return(analog_result);
}

uint16_t convertanalogextended(uint8_t admux) 
{	
	analog_busy=1;
		
	/* set ADMUX (only lower 5 bits) */
	ADMUX |= admux&0x31; ADMUX &= ~((~admux)&0x31);
	
	/*  start conversion */
	ADCSRA |= _BV(ADSC);
	while(analog_busy); /* wait for result */
	return(analog_result);
}


