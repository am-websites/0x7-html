/* avr_usb_board.c - source code for the board */
/* by Andreas M�ller */

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "uart.h"
#include "analog.h"

#define reply_ok() uart_sendstr_P("ok\n")
#define reply_err() uart_sendstr_P("err\n")
#define reply_modeerr() uart_sendstr_P("error: unknown mode or command\n")
#define reply_porterr() uart_sendstr_P("error: no such port\n")
#define reply_biterr() uart_sendstr_P("error: no such bit\n")
#define reply_conferr() uart_sendstr_P("error: not a configuration option\n")
#define reply_analogchannelerr() uart_sendstr("error: analog: no such channel\n")

#define MODE_DEFAULT 		0
#define MODE_RESET			1
#define MODE_TEST			2
#define MODE_SLEEP			3
#define MODE_WAKEUP		4
#define MODE_ANALOG		5
#define MODE_ANALOG_EXTENDED 6
#define MODE_BINARY			7
#define MODE_RANDOM_ANT	8
#define MODE_RANDOM_OSC	9

#define IO_RAW			0
#define IO_DEC			1
#define IO_HEX			2


/* modes

Nr.	Alias	Parameter	Comment

0	d					default - set and get bits manually
1	t					test - periodically send string to output and blink leds
2	p					sleep
3	a		[n]  channels	continually do d/a conversions of n channels and send output to USB
4	b		port,bit		continually send binary port input to USB
*/

/* commands for default mode

Syntax: [command][port][bit](value) - [1byte][1byte][1byte](n bytes)

cmd	arg	desc

s	pbv	set port value
c	pbv	configure port DDR
g	pb	get port value

*/

static char uart_rxbuf[UART_RX_BUFFER_SIZE+1];
uint8_t mode;
uint8_t mode_changed;
uint8_t out_format, in_format;
uint8_t out_use_separator;
char out_separator;
char out_channel_separator;
uint8_t analog_reference, analog_precision;
char *tmpstr;
uint16_t sc_delay,sc_challenge_words[3];

char *helpstring= 	
"\nAVR USB Board\n\n\
modes (syntax: [mode]<param>):\n\
\td\tdefault mode\n\
\tr\treset mode - reset pins to tristated input and mode to d\n\
\tt\ttest mode - blink and send test string\n\
\tp\tsleep\n\
\tan\tcontinuous analog pin input - n: number of channels\n\
\tbpb\tcontinuous binary pin input - p: port, b: bit (a for all)\n\
more modes (extended):\n\
\txra\trandom number generator (antenna on a0)\n\
\txro\trandom number generator (external oscillator)\n\
\txan\textended analog modes (differential input; gain) - n: admux\n\
commands (syntax: [command]<params>):\n\
\th\tprint this help\n\
\tm\tprint current mode\n\
\tz\tconfigure\n\
\tzs\tshow configuration\n\
\tzo[rdh]\tconfigure output (raw, dec or hex)\n\
\tzos[0x]\tconfigure output separator char (zero for none or char)\n\
\tzi[rdh]\tconfigure input (raw, dec or hex)\n\
\tzap[fs]\tconfigure analog precision (fast/8bit or slow/10bit)\n\
\tzar[iv]\tconfigure analog reference voltage (internal or vcc)\n\
\tzcd<val>\tconfigure sc_delay in us (0-65535)\n\
\tzcc[0-2]<val>\tset challenge sequence data (48 bit)\n\
\teg\tget whole eprom content\n\
\ter\tread eprom byte\n\
\tewb\twrite eprom byte b\n\
\tei\tincrease eprom adress\n\
\te0\tset eprom adress to zero\n\
\txsr\tread smartcard on port b\n\
\txsc\tget smartcard challenge response\n\
\txsa\tget a lot of challenge data\n\
\txsh\thard reset smartcard\n\
\txe\techo mode - echo uint16 input value\n\
basic i/o commands (syntax: [command][port][bit]<value>)\n\
\tspbv\tset port p bit b value v\n\
\tcpbv\tconfigure port b bit b value v (i: in o: out)\n\
\tgpb\tget port p bit b (a for all)\n\
\tvc\tget analog value of port A channel c\n\
[one byte], <one or more bytes>\n";

void delay_us(uint16_t us) {
  while (us) {
    us--;
    asm("NOP"); 
    asm("NOP"); 
    asm("NOP"); 
  }
}

void delay_ms( uint16_t ms) {
  while (ms) {
    ms--;
    delay_us(1000);
  }
}

void reset_pins(void){ //sets all pins to input without pull-up (tristate)
    DDRA=0; PORTA=0;
    DDRB=0; PORTB=0;
    DDRC=0; PORTC=0;
}

void set_pwr_led(uint8_t state) {
	if (state==0) {
		PORTD|=_BV(PD4);
	} else {
		PORTD&=~_BV(PD4);
	}
}

void set_pwr_pins(uint8_t state) {
	if (state==0) {
		PORTD|=_BV(PD6)|_BV(PD7);
	} else {
		PORTD&=~(_BV(PD6)|_BV(PD7));
	}
}


void set_mode(uint8_t newmode) {
	mode=newmode;
	mode_changed=1;  /* set mode_changed even if the mode may be the same -> the params may have changed */
}

uint8_t get_in_value_uint8(char* in_str){
	switch (in_format) {
		case IO_DEC:
			return (uint8_t)atoi(in_str);
		case IO_HEX:
			return (uint8_t)strtol(in_str, (char **)NULL, 16);
		case IO_RAW:
			return in_str[0];
	}
	return 0;
}

uint16_t get_in_value_uint16(char* in_str){
	switch (in_format) {
		case IO_DEC:
			return (uint16_t)atol(in_str);
		case IO_HEX:
			return (uint16_t)strtol(in_str, (char **)NULL, 16);
		case IO_RAW:
			return (uint16_t)((uint8_t)in_str[0]*256+(uint8_t)in_str[1]);
	}
	return 0;
}

void get_out_str_uint8(uint8_t out_val,char* out_s) {
	switch (out_format) {
		case IO_DEC:
			itoa(out_val,out_s,10);
			break;
		case IO_HEX:
			itoa(out_val,out_s,16);
			if (out_val<16) {
				out_s[1]=out_s[0];
				out_s[0]='0'; out_s[2]='\0';
			}
			break;
		case IO_RAW:
			out_s[0]=(char)out_val; out_s[1]='\0';
			break;
	}
	return;
}

void uart_send_uint8(uint8_t _val) {
	get_out_str_uint8(_val,tmpstr);
        uart_sendstr(tmpstr);
	if (out_use_separator) uart_sendchar(out_separator);
}

void get_out_str_uint16(uint16_t out_val,char* out_s) {
	switch (out_format) {
		case IO_DEC:
			ltoa(out_val,out_s,10);
			break;
		case IO_HEX:
			ltoa(out_val,out_s,16);
			break;
		case IO_RAW:
			out_s[0]=(char)(out_val/256); out_s[1]=(char)(out_val%256); out_s[2]='\0'; /* high byte first */
			break;
	}
	return;
}

void uart_send_uint16(uint16_t _val) {
	get_out_str_uint16(_val,tmpstr);
        uart_sendstr(tmpstr);
	if (out_use_separator) uart_sendchar(out_separator);
}

void uart_send_uint16_channel(uint16_t _val) {
	get_out_str_uint16(_val,tmpstr);
        uart_sendstr(tmpstr);
	if (out_use_separator) uart_sendchar(out_channel_separator);
}


void cmd_configure(char *conf_str) {
	uint8_t _x;
	switch (conf_str[0]){
		case 's': /* show configuration */
			uart_sendstr("\nconfiguration:\n\n");
			uart_sendstr("output format is ");
			switch (out_format) {
				case IO_RAW:
					uart_sendstr("raw\n");
					break;
				case IO_HEX:	  uart_sendstr("hex\n");
					break;
				case IO_DEC:
					uart_sendstr("dec\n");
					break;
				default:
					uart_sendstr("invalid\n");
			}
			uart_sendstr("output separator is ");
			if (out_use_separator==0) uart_sendstr("off\n"); else { uart_sendstr("on\n");}
			uart_sendstr("output separator char is '");
			uart_sendchar(out_separator);
			uart_sendstr("\ninput format is ");
			switch (in_format) {
				case IO_RAW:
					uart_sendstr("raw\n");
					break;
				case IO_HEX:
					uart_sendstr("hex\n");
					break;
				case IO_DEC:
					uart_sendstr("dec\n");
					break;
				default:
					uart_sendstr("invalid\n");
			}
			uart_sendstr("analog precision is ");
			if (analog_precision==ANALOG_PRECISION_SLOW) {uart_sendstr("slow\n");}
				else {uart_sendstr("fast\n");}
			uart_sendstr("analog reference is ");
			if (analog_reference==ANALOG_REFERENCE_VCC) {uart_sendstr("vcc\n");}
				else {uart_sendstr("internal\n");}
			uart_sendstr("sc_delay is ");
			uart_send_uint16(sc_delay);
			uart_sendstr("\nsc_challeng_words are ");
			for (_x=0;_x<3;_x++) {
				uart_send_uint16(sc_challenge_words[_x]);
			}
			uart_sendchar('\n');
			break;
		case 'o':  /* configure output format */
			switch (conf_str[1]) {
				case 'r':
					out_format=IO_RAW;
					break;
				case 'h':
					out_format=IO_HEX;
					break;
				case 'd': 
					out_format=IO_DEC;
					break;
				case 's':	/* configure separator */
					if (conf_str[2]=='0') {
						out_use_separator=0;
					} else {
						out_separator=conf_str[2];
						out_use_separator=1;
					}
					break;
				default:
					reply_conferr();				
			}
			break;
		case 'i':  /*  configure input format */
			switch (conf_str[1]) {
				case 'r':
					in_format=IO_RAW;
					break;
				case 'h':
					in_format=IO_HEX;
					break;
				case 'd': 
					in_format=IO_DEC;
					break;
				default:
					reply_conferr();				
			}
			break;
		case 'a':  /* configure analog settings */
			switch (conf_str[1]) {
				case 'p': /* configure analog precision */
					if (conf_str[2]=='f') { /* fast */
						analog_precision=ANALOG_PRECISION_FAST;
					} else if (conf_str[2]=='s') {
						analog_precision=ANALOG_PRECISION_SLOW;
					} else {
						reply_conferr();
					}					
					break;
				case 'r': /* configure analog reference */
					if (conf_str[2]=='i') { /* internal */
						analog_reference=ANALOG_REFERENCE_INTERNAL;
					} else if (conf_str[2]=='v') { /* vcc */
						analog_reference=ANALOG_REFERENCE_VCC;
					} else {
						reply_conferr();
					}
					break;
				default:
					reply_conferr();				
			}
			break;
		case 'c': /* configure cardreader */
			switch (conf_str[1]) {
				case 'd': /* configure delay */
					sc_delay=get_in_value_uint16((char *)(&conf_str[2]));
					break;
				case 'c': /* set sc_challenge_words */
					_x=conf_str[2]-'0';
					if (_x>2) {
						uart_sendstr("only 3 challenge words\n");
					}
					sc_challenge_words[_x]=get_in_value_uint16((char *)(&conf_str[3]));
					break;
				default:
					uart_sendstr("no such smartcard configuration option\n");
			}
			break;
		default: reply_conferr();
	}
}

void cmd_eprom(char *conf_str) {
	void eprom_inc_addr(void){
		PORTB|=_BV(0); /* clk*/
		PORTB&=~_BV(0);
	}
	void eprom_rst_addr(void){
		PORTB|=_BV(1); /* rst*/
		PORTB&=~_BV(1);
	}
	uint16_t _i;
	char _byte;
	switch (conf_str[0]){
		case 'g': 
			DDRA=0;
			PORTA=255;
			DDRB=255;
			PORTB=0; /* b0:clk:0 b1:rst:0 b2:!chip enable:0 b3:!output enable:0*/
			eprom_rst_addr();
			for (_i=0; _i<32768;_i++){
				uart_send_uint8(PINA);
				eprom_inc_addr();
			}
			break;
		case 'r':
			DDRA=0;
			PORTA=255;
			DDRB=255;
			PORTB=0;
			uart_send_uint8(PINA);
			break;
		case 'w':
			_byte=get_in_value_uint8(&(conf_str[1]));
			DDRB=255;
			PORTB=12; /*  output disabled->input mode, chip disabled->pulse low to program*/
			DDRA=255; /* use port A for output  (only use this when eprom is in input mode)*/
			PORTA=_byte;
			PORTB=8; /* chip enabled */
			delay_us(100);
			PORTB=12; /* chip disabled */
			DDRA=0; /* port A for input */
			PORTA=255;
			PORTB=4; /* eprom output enabled again, but chip disabled -> verify mode */
			delay_us(50);
			uart_send_uint8(PINA); /* send byte for control */
			break;
		case 'i':
			eprom_inc_addr();
			break;
		case '0':
			eprom_rst_addr();
			break;
	}
}

void cmd_sc_read(void) {
/* b0: Vcc b1: Gnd b2: Rst b4: Clk b5:I/O */
	void sc_clk(void) {
		PORTB|=_BV(PB4);
		delay_us(sc_delay);
		PORTB&=~_BV(PB4);
		delay_us(sc_delay);
	}
	void sc_reset(void) {
		PORTB|=_BV(PB2);
		delay_us(sc_delay);
		sc_clk();
		PORTB&=~_BV(PB2);
		delay_us(sc_delay);
	}
	uint8_t _i,_j,_byte;
	DDRB=_BV(PB0)|_BV(PB1)|_BV(PB2)|_BV(PB3)|_BV(PB4); /*31*/
	PORTB=_BV(PB0); /* only vcc high */
	PORTB|=_BV(PB5); /* enable internal pull-up for input pin */
	sc_reset();
	for (_i=0;_i<64;_i++) { /* 64*8=512 bits */
		_byte=0;
		for (_j=0;_j<8;_j++) {
			if ((PINB&_BV(PB5))>0) {
				_byte+=1<<_j;
			}
			sc_clk();
		}
		uart_send_uint8(_byte);
	}
}

void cmd_sc_hardreset(void) {
	PORTB&=~_BV(PB0); /* vcc power down */
	delay_us(sc_delay);
	PORTB|=_BV(PB0); /* vcc power up */
	delay_us(sc_delay);
}

void cmd_sc_challenge(void) {
/* b0: Vcc b1: Gnd b2: Rst b4: Clk b5:I/O */
	void sc_clk(void) {
		PORTB|=_BV(PB4);
		delay_us(sc_delay);
		PORTB&=~_BV(PB4);
		delay_us(sc_delay);
	}
	void sc_reset(void) {
		PORTB|=_BV(PB2);
		delay_us(sc_delay);
		sc_clk();
		PORTB&=~_BV(PB2);
		delay_us(sc_delay);
	}
	void sc_rst(void) {
		PORTB|=_BV(PB2);
		delay_us(sc_delay);
		PORTB&=~_BV(PB2);
		delay_us(sc_delay);
	}
	void sc_write(void) {
		sc_rst();	
 		sc_clk();
	}
	void sc_writecarry(void) {
		sc_write();
		sc_write();
	}
	void sc_clkalot(uint8_t __num) {
		uint8_t __i;
		for (__i=0;__i<__num;__i++) {
			sc_clk();
		}
	}
	uint8_t _i,_j;
	uint16_t _response;
	DDRB=_BV(PB0)|_BV(PB1)|_BV(PB2)|_BV(PB3)|_BV(PB4); /*31*/
	PORTB=_BV(PB0); /* only vcc high */
	PORTB|=_BV(PB5); /* enable internal pull-up for input pin */
	
	/* set counter to zero */
	sc_reset();
	/* set bit counter to 110 */
	sc_clkalot(110); 
	/* write bit to activate challenge/response */
	sc_write();
	/* 177 clk's */
	sc_clkalot(177);
	/* write challenge sequence (48 bit) */
	PORTB&=~_BV(PB5); DDRB|=_BV(PB5); /* IO is output */
	for (_i=0;_i<3;_i++) {
		for (_j=0;_j<16;_j++) {
			if ((sc_challenge_words[_i]&(1<<_j))>0) {
				PORTB|=_BV(PB5);
			} else {
				PORTB&=~_BV(PB5);
			}
			sc_clk();
		}
	}
	DDRB&=~_BV(PB5); PORTB|=_BV(PB5); /* IO (PB5) is input with pull-up again */
	/* read response (16 bit) */
	_response=0;
	for (_i=0;_i<16;_i++) {
		sc_clkalot(160);
		if ((PINB&_BV(PB5))>0) {
                	_response+=1<<_i;
		}
	}
	/* send back response */
	uart_send_uint16(_response);
}

void cmd_sc_challenge_all(void) {
	uint16_t _k;
	sc_challenge_words[0]=0;
	cmd_sc_challenge();
	for (_k=1;_k!=0;_k++) {
		sc_challenge_words[0]=_k;
		cmd_sc_challenge();
	}
}

//Signal can't be interrupted, Interrupt can
//SLEEP Signal from FT232
void SIGNAL(SIG_INTERRUPT1) {
	if (PIND&&_BV(PD3)==0) {	  /* sleep mode */
		set_mode(MODE_SLEEP);
	} else {
		set_mode(MODE_WAKEUP);
	}
}


int main(void) {
	char cmd=0,portc=0,bitc=0;
	tmpstr=(char *)malloc(6); /* for short time use only*/
	char *param=0;
	uint8_t newcommand;
	uint8_t i,j,bit,num;
	uint8_t *port, *portin, *ddr;
	
	bit=0;num=0;portin=0;
	mode=MODE_DEFAULT;
	newcommand=0;
	out_format=IO_DEC;
	out_use_separator=1;
	out_separator=' ';
	out_channel_separator=',';
	in_format=IO_DEC;
	analog_precision=ANALOG_PRECISION_SLOW;
	analog_reference=ANALOG_REFERENCE_VCC;
	sc_delay=10; sc_challenge_words[0]=0; sc_challenge_words[1]=0; sc_challenge_words[2]=0;
	
	reset_pins();
	//PORT D: Pin PD4 is Output (Power LED), Pins PD6,PD7 are Output (sleep state), PD3 is Input (sleep state)
	DDRD=_BV(PD4)|_BV(PD6)|_BV(PD7);   /*PD4,6,7 as output, all others as input - UART Pins will be configured later*/
	set_pwr_led(1); set_pwr_pins(1);
	//Enable Interrupts
	GICR|=_BV(INT0)|_BV(INT1);
	/* any level change on int 1 triggers interrupt */
    	MCUCR&=~_BV(ISC11); MCUCR|=_BV(ISC10);
    	//globally enable Interrupts
    	sei();
	uart_init();
	uart_reset(); /* clear garbabge */	

	while(1){
		if (uart_getrxbufnl(uart_rxbuf)!=0) {
			switch (uart_rxbuf[0]) {
				/* modes */
				case 'd':	/* default mode */
					set_mode(MODE_DEFAULT);
					break;
				case 'r':  /* reset mode */
				case 'R':
					set_mode(MODE_RESET);
					break;
				case 't': /* test mode */
					set_mode(MODE_TEST);
					break;
				case 'p': /* sleep mode */
					set_mode(MODE_SLEEP);
					break;
				case 'a': /* analog mode */
					set_mode(MODE_ANALOG);
					param=&(uart_rxbuf[1]);
					break;
				case 'b': /* binary mode */
					set_mode(MODE_BINARY);
					portc=tolower(uart_rxbuf[1]);
					bitc=tolower(uart_rxbuf[2]);
					break;
				case 'x': /* even more modes */
					switch (uart_rxbuf[1]) {
						case 'r': set_mode(MODE_RANDOM_ANT);
							  if (uart_rxbuf[2]=='o') set_mode(MODE_RANDOM_OSC);
							  break;
						case 's': 
							switch (uart_rxbuf[2]) {
								case 'r':
									cmd_sc_read(); /* read smartcard */
									break;
								case 'c': 
									cmd_sc_challenge(); /* challenge phonecard */
									break;
								case 'a':
									cmd_sc_challenge_all();
									break;
								case 'h': 
									cmd_sc_hardreset(); /* do a hard reset of the smartcard */
									break;
								default: reply_err();
							}
							break;
						case 'e': /* echo mode - resend input uint16 value */
							uart_send_uint16(get_in_value_uint16((char *)(&uart_rxbuf[2])));
							break;
						case 'a': /* extended analog mode */
							set_mode(MODE_ANALOG_EXTENDED);
							param=&(uart_rxbuf[2]);
							break;
						default: reply_modeerr();
					}
					break;
				/* commands */
				case 'h':
				case 'H':
					uart_sendstr(helpstring);
					break;
				case 'm':
					uart_sendstr("mode is ");
					uart_sendchar(mode+'0'); uart_sendchar('\n');
					break;			
				case 'z': /* configure */	
					cmd_configure(&(uart_rxbuf[1]));
					break;
				case 'e': /* eprom */
					cmd_eprom(&(uart_rxbuf[1]));
					break;
				/* commands for default mode */
				case 's':
				case 'S':
				case 'c':
				case 'C':
					if ((cmd=='c'||cmd=='C')&&(tolower(uart_rxbuf[3])=='o'||tolower(uart_rxbuf[3])=='i')) {
						if (tolower(uart_rxbuf[3])=='o') {  /*  configure as output */
							if (tolower(uart_rxbuf[2])=='a') {
								num=255;
							} else {
								num=1;
							}
						} else {
							num=0; /* configure as input */
						}
							
					} else {
						num=get_in_value_uint8(&(uart_rxbuf[3]));
					}
				case 'g':
				case 'G':
					newcommand=1;
					cmd=tolower(uart_rxbuf[0]);
					portc=tolower(uart_rxbuf[1]);
					bitc=tolower(uart_rxbuf[2]);
					param=&(uart_rxbuf[3]);
					break;
				case 'v': /* get analog channel */
				case 'V': 
					newcommand=1;
					cmd=tolower(uart_rxbuf[0]);
					portc='a';
					bitc=tolower(uart_rxbuf[1]);
					break;
				default: 
					reply_modeerr();
			}			
		}
		
		switch(mode) {
			case MODE_DEFAULT:
				if (newcommand) {
				 	newcommand=0;
					switch (portc) {
						case 'a':
							port=(uint8_t *)(&PORTA);
							ddr=(uint8_t *)(&DDRA);	
							portin=(uint8_t*)(&PINA);
							break;
						case 'b':
							port=(uint8_t *)(&PORTB);
							ddr=(uint8_t *)(&DDRB);
							portin=(uint8_t*)(&PINB);
							break;
						case 'c':
							port=(uint8_t *)(&PORTC);
							ddr=(uint8_t *)(&DDRC);
							portin=(uint8_t*)(&PINC);
							break;
						default:
							reply_porterr();
							continue;
					}								
					switch (cmd) {
						case 's':
						case 'c':
							if (bitc=='a') {
								if (cmd=='s') {
									(uint8_t)(*port)=num;
								} else {
									(uint8_t)(*ddr)=num;
								}
							} else if (isdigit(bitc)) {
								bit=bitc-'0';
								if(bit<8&&(num==0||num==1)) {
									if (num==0) {
										if (cmd=='s') {
											(uint8_t)(*port) &= ~_BV(bit);
										} else {
											(uint8_t)(*ddr) &= ~_BV(bit);
										}
									} else {
										if (cmd=='s') {
											(uint8_t)(*port) |= _BV(bit);
										} else {
											(uint8_t)(*ddr) |= _BV(bit);
										}
									}
								} else {
									reply_biterr();
								}
							} else {
								reply_biterr();
							}
							break;
						case 'g':
							num=(uint8_t)(*portin);
							if (bitc=='a') {
								uart_send_uint8(num);
							} else if (isdigit(bitc)) {
								bit=bitc-'0';
								if(bit<8) {
									if ((num&_BV(bit))>0) {
										num=1;
									} else {
										num=0;
									}
									uart_send_uint8(num); /* only one bit */
								} else {
									reply_biterr();
								}
							} else {
								reply_biterr();
							}
							break;
						case 'v': /*  get analog channel */
							DDRA=0;
							PORTA=0;
							num=bitc-'0';
							if (!isdigit(bitc)||num>8) {
								reply_analogchannelerr();
							} else {
								initanalog(num, analog_reference, analog_precision);
								uart_send_uint16(convertanalog(num));
							}
							break;
					}
				}
				break;
			case MODE_RESET:
				reset_pins();
				newcommand=0;
				set_mode(MODE_DEFAULT);
				break;
			case MODE_TEST:
				uart_sendstr("hello world 0123456789\n");
				DDRA=255;DDRB=255;DDRC=255;
				for (i=0;i<8;i++) {
					PORTA&=~_BV(i); PORTB&=~_BV(i); PORTC&=~_BV(i);
					delay_ms(100);
					PORTA=255; PORTB=255; PORTC=255;
				}
				break;
			case MODE_SLEEP:
				reset_pins();
				set_pwr_led(0);
				set_pwr_pins(0);
  				//set_sleep_mode(SLEEP_MODE_IDLE);
				/* set Interrupt Trigger to low level --> the only option to wakeup MCU from sleep mode */
    				MCUCR&=~(_BV(ISC10)|_BV(ISC11));
				set_sleep_mode(SLEEP_MODE_PWR_DOWN);
				sleep_mode(); 
				break;
			case MODE_WAKEUP:
				set_pwr_led(1);
				set_pwr_pins(1);
				/* any level change on int 1 triggers interrupt */
    				MCUCR&=~_BV(ISC11); MCUCR|=_BV(ISC10);
				set_mode(MODE_DEFAULT);
				break;
			case MODE_ANALOG:
				DDRA=0;
				PORTA=0;
				if (mode_changed) {
					mode_changed=0;
					num=param[0]-'0';
					if (!isdigit(param[0])||num>8) {
						reply_analogchannelerr();
						set_mode(MODE_DEFAULT);
						break;
					}
					initanalog(num, analog_reference, analog_precision);
				}
				for (i=0;i<num;i++) {
					if (i==num-1) {
						uart_send_uint16(convertanalog(i));
					} else {
						uart_send_uint16_channel(convertanalog(i));
					}
				}
				break;
			case MODE_ANALOG_EXTENDED:
				DDRA=0;
				PORTA=0;
				if (mode_changed) {
					mode_changed=0;
					num=get_in_value_uint8(param);
					initanalog(8, analog_reference, analog_precision); /* init all channels... */
				}
				uart_send_uint16(convertanalogextended(num));
				break;
			case MODE_BINARY:
				if (mode_changed) {
					mode_changed=0;
					switch (portc) {
						case 'a':
							port=(uint8_t *)(&PORTA);
							ddr=(uint8_t *)(&DDRA);	
							portin=(uint8_t*)(&PINA);
							break;
						case 'b':
							port=(uint8_t *)(&PORTB);
							ddr=(uint8_t *)(&DDRB);
							portin=(uint8_t*)(&PINB);
							break;
						case 'c':
							port=(uint8_t *)(&PORTC);
							ddr=(uint8_t *)(&DDRC);
							portin=(uint8_t*)(&PINC);
							break;
						default:
							reply_porterr();
							set_mode(MODE_DEFAULT);
							continue;
					}
					if (bitc=='a') { 
						(uint8_t)(*ddr) =0;
						bit=255;
					} else if (isdigit(bitc)) {
						bit=bitc-'0';
						if(bit<8) {
							bit=_BV(bit);
							(uint8_t)(*ddr) &=~bit; /* set port bit to 0 (input)*/
						} else {
							reply_biterr();
							set_mode(MODE_DEFAULT);
						}
					} else {
						reply_biterr();
						set_mode(MODE_DEFAULT);
					}
					
				}
				/* send the value*/
				num=((uint8_t)(*portin))&bit;
				if (bit==255) { /* send all bits */
					uart_send_uint8(num);
				} else {  /* only one bit */
					num=(num>0)?1:0;
					uart_send_uint8(num);
				}
				break;
			case MODE_RANDOM_ANT:
				if (mode_changed) {
					initanalog(1, analog_reference, analog_precision);
				}
				num=0;
				for (i=0;i<8;i++) {
				   bit=convertanalog(0)%2;
				   num+=bit<<i;
				}
				uart_send_uint8(num);
				break;
			case MODE_RANDOM_OSC:
				if (mode_changed) {
					DDRA&=~_BV(0);  /* PIN A0 is input */
					DDRA|=_BV(2);	/* PIN A2 is output */
					PORTA=_BV(2);
				}
				num=0;
				for (j=0;j<8;j++) {
						if ((PINA&_BV(0))>0) num += 1<<j;
						delay_us(1000);
					}
				uart_send_uint8(num);
				break;
			default: mode=MODE_DEFAULT;		
		
		}
	}

}
