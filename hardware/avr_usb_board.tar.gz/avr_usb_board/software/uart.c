/*
* Author: Guido Socher, Copyright: GPL 
* Adjusted for AVR libc 1.04 and other things by Andreas Mueller
* Clock frequency     : 8,000000 MHz
*/

#include <avr/signal.h>
#include <string.h>
#include <avr/io.h>
#include "uart.h"


/* the RTSOUT must be on port D */
#define RTSOUT PD2

#define ATMEGA32 1
#define FOSC 8000000 
#define BAUD 9600

//#define UBRR_VALUE (FOSC/(16*BAUD))-1 
//#define UBRR_VALUE 50 //for 9600 Baud -> stuff above would get me 51 which doesnt work
/* maximum speed */
#define UBRR_VALUE 0


static char uart_rxbuf[UART_RX_BUFFER_SIZE+1];
volatile static unsigned char uart_rx_pos; /* end of string in rx */
volatile static unsigned char uart_rx_linecomplete; /* one complete line in buffer */
volatile static unsigned char uart_tx_busy; /* uart is still transmitting */

/* the following function will be called when the receive is complete 
 * SIGNAL =interrupts are disabled */
SIGNAL(SIG_UART_RECV) {
	uart_rxbuf[uart_rx_pos]=UDR;
	if (uart_rxbuf[uart_rx_pos] == '\n' || uart_rxbuf[uart_rx_pos] == '\r'){
		uart_rx_linecomplete=1;
	}else{
		uart_rx_pos++;
		/* prevent overflow */
		if (uart_rx_pos > UART_RX_BUFFER_SIZE){
			uart_rx_pos=0;
		}
		if (uart_rx_pos > UART_RX_BUFFER_SIZE -1 ){
			/* buffer full, set RTS/CTS to off */
			uart_rx_linecomplete=1;
			//cbi(PORTD,RTSOUT);
			PORTD &= ~_BV(RTSOUT);
		}
	}
}

/* the following function will be called when the data
* in UDR register is sent out, INTERRUPT=interrupts are not disabled */
//==== SIG_UART_DATA
INTERRUPT(SIG_UART_TRANS) {
	uart_tx_busy=0;
}


void uart_init(void) 
{
	uart_tx_busy=0;
	uart_rx_pos=0;
	uart_rx_linecomplete=0;

	/* Set baud rate */
	UBRRH = (unsigned char)(UBRR_VALUE>>8);
	UBRRL = (unsigned char)UBRR_VALUE;
	/* enable double speed mode*/
	UCSRA |= _BV(U2X);
		
	/* Enable receiver and transmitter */
	UCSRB = (1<<RXEN)|(1<<TXEN)|_BV(TXCIE)|_BV(RXCIE);
	
	/* format: asynchronous, 8data, no parity, 1stop bit */
        //UCSRC = (1<<URSEL)|(3<<UCSZ0);
	/* Set frame format: 8data, 2stop bit */
	//UCSRC = (1<<URSEL)|(1<<USBS)|(3<<UCSZ0);
	
	/* Set frame format: 8data, 2stop bit, and odd parity bit */
	/* stty settings: stty ospeed 1000000 parenb parodd cs8 cstopb -F /dev/ttyUSB0 */
	/*			stty ispeed 1000000 parenb parodd cs8 cstopb -F /dev/ttyUSB0 */
	UCSRC = (1<<URSEL)|(1<<USBS)|(3<<UCSZ0)|(1<<UPM1)|(1<<UPM0);



	/* configure the RTS as output */
	DDRD |= _BV(RTSOUT);
	/* RTS on = I am ready to receive data */
	PORTD |= _BV(RTSOUT);

	/* you must enable interrupt in main prog by calling sei() */

}
void uart_reset(void)
{
	uart_tx_busy=0;
	uart_rx_pos=0;
	uart_rx_linecomplete=0;
	//sbi(PORTD,RTSOUT);
	PORTD |= _BV(RTSOUT);
}
/* send one character to the rs232 */
void uart_sendchar(char c) 
{
	while (uart_tx_busy);
	uart_tx_busy=1;
	//outp(c, UDR);
	UDR = c;
}
/* send string to the rs232 */
void uart_sendstr(char *s) 
{
	while (*s){
		uart_sendchar(*s);
		s++;
	}
}


void uart_sendstr_p(const prog_char *progmem_s)
/* print string from program memory on rs232 */
{
	char c;
	while ((c = pgm_read_byte(progmem_s++))) {
		uart_sendchar(c);
	}

}


/* read a complet line from the rs232 */
unsigned char uart_getrxbufnl(char *uart_outbuf)  
{
	if (uart_rx_linecomplete==0) return(0);
	uart_rxbuf[uart_rx_pos]='\0';
	strcpy(uart_outbuf,uart_rxbuf);
	/* RTS on = I am ready to receive data */
	//sbi(PORTD,RTSOUT);
	PORTD |= _BV(RTSOUT);
	uart_rx_pos=0;
	uart_rx_linecomplete=0;
	return(1);
}

