#!/usr/bin/perl
#
# read in a hexdump of a phonecard
#
#

use Switch;

sub numbits {
	$val=hex($_[0]);
	$x=0;
	for (0..7) {
  		$x+=($val&(1<<$_))>0;
	}
	return $x;
}

my @content=(
{ desc => 'cardtype', 'D0' => 'old card', DD => 'new card (eurochip)'}, #byte 0: cardtype
{ desc => 'country', '2A' => 'Switzerland', '2F' => 'Germany', '37' => 'Netherlande', '3B' => 'Greece'}, #byte 1: cardtype
{ desc => 'F and 10th digit of serial number'}, #byte 2
{ desc => 'manufacturer of the card', CA => 'Gemplus'}, #byte 3
{ desc => 'value and relase year (binary inverted)' }, #byte 4
{ desc => '9th digit of sn and month of issue' }, #byte 5
{ desc => '7th and 8th digit of sn'}, #byte 6
{ desc => '5th and 6th digit of sn'}, #byte 7
{ desc => '4096*(number of bits set) units'}, #byte 8
{ desc => '512*(number of bits set) units'}, #byte 9
{ desc => '64*(number of bits set) units'}, #byte 10
{ desc => '8*(number of bits set) units'}, #byte 11
{ desc => '1*(number of bits set) units'}, # byte 12
);

if ($#ARGV<0) {
	open FILE,"-";
} else {
	$file=$ARGV[0];
	open FILE, "<$file" || die "ERROR: can't open $file";
}

$/=' ';
$byte=0;

print "byte nr\thex val\tdescription\n";
print "=============================\n";

while (<FILE>) {
	chomp;
	$_ =~ s/\n//g;;
	$val=hex($_);
	$hexval=uc($_);
	$data[$byte]=$hexval;
	switch ($byte) {
		case [0..12] {
			print $byte."\t".$hexval."\t".$content[$byte]{"desc"}.": ";
			if ($content[$byte]{$hexval} ne "") {
				print $content[$byte]{$hexval}."\n";
			} else {
				print "unknown\n";
			}
		}
		case 13 {
			 print $byte."\t".$hexval."\t"."area set to FF (until byte 39)\n14-39\t"; 
		}
		case [14..39] {
			print $hexval." ";
		}
		case 40 {
			print "\n".$byte."\t".$hexval."\t"."bytes 40-43: old swiss cards: 00 00 00 00 Eurochip: 7F FF FF FF\n41-43\t";
		}
		case [41..43] {
			print $hexval." ";
		}
		case 44 {
			print "\n".$byte."\t".$hexval."\t"."bytes 44-47: old swiss cards: F8 88 4A A8 Eurochip: FF FF FF FF\n45-47\t";
		}
		case [45..47] {
			print $hexval." ";
		}
		case 48 {
			print "\n".$byte."\t".$hexval."\t"."bytes 48-63 set to FF\n49-63\t";
		}
		case [49..63] {
			print $hexval." ";
		}
		else {
			print $byte."\t".$hexval."\tunknown\n";
		}
	}
	$byte++;
	if ($byte==64) {
		last;
	}
}

print "\n\n";

print "nominal value of card: ";
$val=hex(substr($data[4],0,1));
if ($val==6) {
	print "20 SFr.\n";
} elsif ($val==2) {
	print "10 SFr.\n";
} elsif ($val==4) {
	print "5 SFr.\n";
} else {
	print "strange\n";
}

printf("digits 5-10 of serial number: %s%s%s%s%s%s\n",substr($data[7],0,1),substr($data[7],1,1),substr($data[6],0,1),substr($data[6],1,1),substr($data[5],0,1),substr($data[2],1,1));

print "units: ".(4096*numbits($data[8])+512*numbits($data[9])+64*numbits($data[10])+8*numbits($data[11])+numbits($data[12]))."\n";
exit(0);

