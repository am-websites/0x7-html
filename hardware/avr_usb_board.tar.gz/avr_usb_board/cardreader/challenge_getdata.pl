#!/usr/bin/perl

use Time::HiRes qw( usleep);

$usbfile="/dev/ttyUSB0";
$outfile="responses.txt";
$/=' ';

open(USBFILE,"+<",$usbfile) || die "ERROR: can't open $usbfile";
open(OUTFILE,">>",$outfile) || die "Error:can't open $outfile";

#$val=<USBFILE>;
#printf(OUTFILE " ");

for($i=0;$i<65535;$i++) {
	printf(USBFILE "xsh\n");
	usleep(10000);
	printf(USBFILE "zcc0%d\n",$i);
	usleep(10000);
	printf(USBFILE "xsc\n");
	usleep(10000);
	$val=<USBFILE>;
	printf("$val ");
	usleep(10000);

}

close(USBFILE);
close(OUTFILE);
