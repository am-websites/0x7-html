/*
GeekClock Source Code
*/

/* 
Pin		Funktion				Default			Direction
=================================================
PB0		Push Button LED		high (LED off)		Out
PB1		AmpSwitch+SinGenPwr	high (AMP off)	Out
PB2		Blue LEDs: D min		low or nc			Out
PB3		Blue LEDs: D hour		low or nc			Out
PB4		Blue LEDs: RST		low or nc			Out
PB5		Blue LEDs: CLK		low or nc			Out

PC0		set Clock: CLK			low or nc			Out
PC1		set Clock: RST			low or nc			Out
PC2		set Clock: D			low (or nc, no R)	Out
PC3		set Clock: Counter: PE	low or nc			Out
PC4		Signal Out			high (no SigOut)	Out
PC5		Oscillator Reset		low or nc			Out

PD0		DCF Module: Enable	low (disable)		Out
PD1		DCF Module: Signal	high				In
PD2		Alarm Signal			low				In (Interrupt)
PD3		Push Button Signal		high (not pressed)	In (Interrupt)
PD4		DCF Module: Pow Sup	high (no power)	Out
PD5		read Clock: Input Sig	low				In 
PD6		read Clock: CLK		low or nc			Out
PD7		read Clock: Shift/Load	high or nc		Out
*/

#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <string.h>   //contains strlen
#include <stdio.h>  //contains sprintf
#include <stdlib.h> //contains rand,srand

#define F_CPU 4000000UL		  // 4 MHz
#define BUTTON_DELAY_MS 1	//this should be kept small because button_down_time is used as seed for rand
#define DOZE_TIME_SEC 300	//wait 5 min before trying to wake me again

#define MORSE_DOT_TIME 100
#define MORSE_DASH_TIME 3*MORSE_DOT_TIME
#define MORSE_LETTERSPACE_TIME 3*MORSE_DOT_TIME
#define MORSE_WORDSPACE_TIME 7*MORSE_DOT_TIME

#define DCF_MAX_RETRIES 5
#define DCF_SAMPLE_DELAY_MS 10
#define DCF_LEVELCHANGE_DELAY_MS 30

uint8_t state;
uint8_t state_changed;

#define STATE_IDLE 0				//nothing to do; MCU should go to sleep in the near future
#define STATE_WAKEUP 1			//I am supposed to wake up now -> play some silly sounds
#define STATE_DOZE 2				//sleeping again -> wait 5 min and try again
#define STATE_WAKEUP_END 3		//confirm and go to sleep (adjust time with dcf before)
#define STATE_SHOW_TIME 4		//showing time
#define STATE_SET_TIME_DCF 5	//getting dcf time 
#define STATE_SET_TIME_DCF_VERBOSE 6 

//possible modes: showing time during day, "" during night, "" during wakeup, setting time with dcf,...

//default action: go to STATE_IDLE

uint8_t dcf_state;

#define DCF_STATE_START 0		//set some variables and start the first try -> next state: DCF_STATE_WAIT
#define DCF_STATE_RETRY 1		//start the next try to get the time -> next state: DCF_STATE_WAIT
#define DCF_STATE_WAIT 2		//wait for the first bit of the minute -> next state: DCF_STATE_SKIP
#define DCF_STATE_SKIP	3		//skip some unneeded bits at the beginning -> next state: DCF_STATE_GET_MIN
#define DCF_STATE_GET_MIN 4		//get minute bits -> next state: DCF_STATE_GET_HR
#define DCF_STATE_GET_HR 5		//get hour -> next state: DCF_STATE_CHECK
#define DCF_STATE_CHECK 6		//check parity and time -> set time and return (next state: DCF_STATE_INIT) or continue (next state: DCF_STATE_WAIT)
#define DCF_STATE_DONE 7		//switch off power and return  <--- this is set by interrupts

uint8_t get_hr, get_min, get_sec;
uint16_t button_down_time, button_up_time;

void delay_us(uint16_t us) {
  while (us) {
    us--;
    //asm("NOP"); 
  }
}

void delay_ms( uint16_t ms) {
  while (ms) {
    ms--;
    delay_us(1000);
  }
}

void sleep(void) {
  //wichtig: Sleep Mode != Output Tristated...
  GICR|=_BV(INT0); //enable wakeup interrupt
  //set sleep mode to power down
  //MCUCR&=~_BV(SM0)&~_BV(SM2); MCUCR|=_BV(SM1);
  //MCUCR|=_BV(SE); //enable Sleep Mode
  //asm ("sleep");
  set_sleep_mode(SLEEP_MODE_PWR_DOWN);
  sleep_mode(); 
}

void initialize(void){
    //Enable all Pins of Port B as Output
    DDRB|=_BV(PB0)|_BV(PB1)|_BV(PB2)|_BV(PB3)|_BV(PB4)|_BV(PB5); //enable PB0-PB5 as Output
    PORTB |= _BV(PB0)|_BV(PB1);  PORTB &= ~_BV(PB2)&~_BV(PB3)&~_BV(PB4)&~_BV(PB5);
    //Enable all Pins of Port C as Output
    DDRC|=_BV(PC0)|_BV(PC1)|_BV(PC2)|_BV(PC3)|_BV(PC4)|_BV(PC5); //enable PC0-PC5 as Output 
    PORTC |= _BV(PC4); PORTC &= ~_BV(PC0)&~_BV(PC1)&~_BV(PC2)&~_BV(PC3)&~_BV(PC5);
    //Enable some Pins of Port D as Output, others as Input
    DDRD|=_BV(PD0)|_BV(PD4)|_BV(PD6)|_BV(PD7); DDRD&=~_BV(PD1)&~_BV(PD2)&~_BV(PD3)&~_BV(PD5);
    PORTD |= _BV(PD4)|_BV(PD7); PORTD&= ~_BV(PD0)&~_BV(PD1)&~_BV(PD2)&~_BV(PD3)&~_BV(PD5)&~_BV(PD6);
    //Enable Interrupts
    GICR|=_BV(INT0)|_BV(INT1);
    //set Interrupt Trigger to low level --> the only option to wakeup MCU from sleep mode
    MCUCR&=~(_BV(ISC00)|_BV(ISC01)|_BV(ISC10)|_BV(ISC11)); //set MCUCR register, bits ISC00-11 to zero
    //globally enable Interrupts
    //sei();  //wait until time is set
}


void set_tone(unsigned char state) {
  if (state) {
    PORTB &= ~_BV(PB1);
  } else {
    PORTB |= _BV(PB1);
  }
}

void set_button_led(unsigned char state) {
  if (state) {
    PORTB &= ~_BV(PB0);
  } else {
    PORTB |= _BV(PB0);
  }
}

void set_leds_rst(void) {
  PORTB|=_BV(PB4);
  PORTB&=~_BV(PB4);
}

void set_leds(uint8_t hr, uint8_t min, uint16_t shift_delay) {
  set_leds_rst();
  int8_t i;
  for(i=5;i>=0;i--) {
    if (((1<<i)&hr)>0) {
      PORTB|=_BV(PB3);
    } else {
      PORTB&=~_BV(PB3);
    }
    if (((1<<i)&min)>0) {
      PORTB|=_BV(PB2);
    } else {
      PORTB&=~_BV(PB2);
    }
    PORTB|=_BV(PB5);  //CLK
    PORTB&=~_BV(PB5);
    if (shift_delay>0) delay_ms(shift_delay);
  }
  //the following is important, because if each D pin that's still high will source about 0.5 mA
  PORTB&=~_BV(PB2)&~_BV(PB3); //set both D outputs to low
}

void reset_oscillator(void) {
  PORTC|=_BV(PC5);
  PORTC&=~_BV(PC5);
}

void reset_clock_set_register(void) {
   PORTC|=_BV(PC1);
   PORTC&=~_BV(PC1);
}

void clock_preset_enable(void) {
   PORTC|=_BV(PC3);
   PORTC&=~_BV(PC3);
}

void set_clock_write_4bits(uint8_t bits) {
  int8_t i;
  for (i=3;i>=0;i--){
    if (((1<<i)&bits)>0) {   //set D
      PORTC|=_BV(PC2);
    } else {
      PORTC&=~_BV(PC2);
    }
    PORTC|=_BV(PC0);  //CLK
    PORTC&=~_BV(PC0);
  }
  PORTC&=~_BV(PC2);
}

void set_time(uint8_t hr, uint8_t min, uint8_t sec) {
  reset_clock_set_register();
  //read in hours
  set_clock_write_4bits(hr/10);
  set_clock_write_4bits(hr%10);
  //read in minutes
  set_clock_write_4bits(min/10);
  set_clock_write_4bits(min%10);
  //read in seconds
  set_clock_write_4bits(sec/10);
  set_clock_write_4bits(sec%10);
  //do the setting
  reset_oscillator();  //reset 32kHz oscillater counter
  clock_preset_enable();  //read values into main clock counter
  reset_clock_set_register();  //reset registers - not really necessary
}


void get_clock_shift_load(void) {
  PORTD&=~_BV(PD7);
  PORTD|=_BV(PD7);
}

uint8_t get_clock_read_4bits(void) {
  int8_t i, bits;
  bits=0;
  for (i=0;i<4;i++){
    bits=bits<<1;
    bits|=((PIND&_BV(PD5))>0);
    PORTD|=_BV(PD6);
    PORTD&=~_BV(PD6);
  }
  return bits;
}

void get_time(void) {
  uint8_t tmp;
  get_clock_shift_load();
  tmp=get_clock_read_4bits();
  get_hr=10*tmp+get_clock_read_4bits();
  tmp=get_clock_read_4bits();
  get_min=10*tmp+get_clock_read_4bits();
  tmp=get_clock_read_4bits();
  get_sec=10*tmp+get_clock_read_4bits();
}


void morse_char(char *chr){
  uint8_t i;
  uint8_t len=strlen(chr);
  for (i=0;i<len;i++) {
    if (state_changed) return;
    switch (chr[i]) {
       case '.': set_tone(1);
                    delay_ms(MORSE_DOT_TIME);
		    set_tone(0);
		    delay_ms(MORSE_DOT_TIME);
		    break;
       case '-': set_tone(1);
                    delay_ms(MORSE_DASH_TIME);
		    set_tone(0);
		    delay_ms(MORSE_DOT_TIME);
		    break;
       case '/': delay_ms(MORSE_LETTERSPACE_TIME-MORSE_DOT_TIME);  //dot time delay is already over
		    break;
       case ' ': delay_ms(MORSE_WORDSPACE_TIME-MORSE_DOT_TIME-MORSE_LETTERSPACE_TIME); //dot time+letterspace time delay is already over
		    break;
    }
  }
}

void out_morse(char *message) {
  uint8_t i; char *chr;
  uint8_t len=strlen(message);
  message=strlwr(message);
  for (i=0;i<len;i++) {
    if (state_changed) return;
    switch (message[i]) {
       case ' ': chr=" "; break;
       case 'a': chr=".-/"; break;
       case 'b': chr="-.../"; break;
       case 'c': chr="-.-./"; break;
       case 'd': chr="-../"; break;
       case 'e': chr="./"; break;
       case 'f': chr="..-./"; break;
       case 'g': chr="--./"; break;
       case 'h': chr="..../"; break;
       case 'i': chr="../"; break;
       case 'j': chr=".---/"; break;
       case 'k': chr="-.-/"; break;
       case 'l': chr=".-../"; break;
       case 'm': chr="--/"; break;
       case 'n': chr="-./"; break;
       case 'o': chr="---/"; break;
       case 'p': chr=".--./"; break;
       case 'q': chr="--.-/"; break;
       case 'r': chr=".-./"; break;
       case 's': chr=".../"; break;
       case 't': chr="-/"; break;
       case 'u': chr="..-/"; break;
       case 'v': chr="...-/"; break;
       case 'w': chr=".--/"; break;
       case 'x': chr="-..-/"; break;
       case 'y': chr="-.--/"; break;
       case 'z': chr="--../"; break;
       case '1': chr=".----/"; break;
       case '2': chr="..---/"; break;
       case '3': chr="...--/"; break;
       case '4': chr="....-/"; break;
       case '5': chr="...../"; break;
       case '6': chr="-..../"; break;
       case '7': chr="--.../"; break;
       case '8': chr="---../"; break;
       case '9': chr="----./"; break;
       case '0': chr="-----/"; break;
       case '.': chr=".-.-.-/"; break;
       case ',': chr="--..--/"; break;
       case ':': chr="---.../"; break;
       case '?': chr="..--../"; break;
       case '=': chr="-...-/"; break;
       case '-': chr="-....-/"; break;
       case '/': chr="-..-./"; break;
       case '+': chr=".-.-./"; break;
       case '\'': chr=".----./"; break;
       case '(': chr="-.--./"; break;
       case ')': chr="-.--.-/"; break;       
       default: chr=""; break;
    }
    morse_char(chr);
  }
  return;
}

void out_morse_time(void) {
  char timestr[20];
  get_time();
  sprintf(timestr,"time is %d:%d",get_hr,get_min);
  out_morse(timestr);
  return;
}

void out_morse_wakeup_message(uint8_t num) {  //this is something like fortune for the morning. messages could be outsourced to eeprom, but as long as there's enough space, this is easier
   switch(num%11) {
        case 0: out_morse("wakeup  ");
	  break;
	case 1: out_morse("good morning  ");
          break;
	case 2: out_morse("a new day has come  ");
	  break;
	case 3: out_morse("get up  ");
	  break;
	case 4: out_morse("get out of bed  ");
	  break;
	case 5: out_morse("what are you waiting for? ");
	  break;
	case 6: out_morse_time();
	  break;
	case 7: out_morse("carpe diem ");
	  break;
	case 8: out_morse("open your eyes ");
	  break;
	case 9: out_morse("time is now ");
	  break;
	case 10: out_morse("if you can hear this, you need to get out of bed ");
	  break;
   }
   return;
}

/* 
rain warning:

rain or other special conditions may partially block the signal, which ca result in a fast changing signal (->no startbit)
it's important that no method is blocking under any circumstances
*/

void dcf_set_power(uint8_t state) {
  if (state) {
    PORTD &= ~_BV(PD4);  //power on
    PORTD |= _BV(PD0); //module enable
  } else {
    PORTD &= ~_BV(PD0); //module disable
    PORTD |= _BV(PD4); //power off
  }
  return;
}

uint8_t dcf_get_input(void){
  return ((PIND&_BV(PD1))>0);
}

uint8_t dcf_get_next_bit(uint8_t verbose) {  //return values: 0 -> bit is zero; 1 -> bit is one; 2-> bit is startbit and zero; 3-> bit is startbit and one; 4-> long low delay (error); 5 -> long high delay (error)
  uint16_t lowcount=0, highcount=0, lasthighcount;
  while (lowcount*DCF_SAMPLE_DELAY_MS<DCF_LEVELCHANGE_DELAY_MS) {
    delay_ms(DCF_SAMPLE_DELAY_MS);
    if (dcf_get_input()==1) { 
      highcount++;
      lowcount=0;
    } else {
      lowcount++;
    }
    if (highcount*DCF_SAMPLE_DELAY_MS>3000) { return 5; } //high signal for some seconds -> error
  }
  if (verbose) set_tone(1);
  lasthighcount=highcount;
  highcount=0;
  while (highcount*DCF_SAMPLE_DELAY_MS<DCF_LEVELCHANGE_DELAY_MS) {
    delay_ms(DCF_SAMPLE_DELAY_MS);
    if (dcf_get_input()==0) {
      lowcount++;
      highcount=0;
    } else {
      highcount++; 
    }
    if (lowcount*DCF_SAMPLE_DELAY_MS>3000) { return 4; } //no signal for some seconds -> error  //the value might be set as low as 300, but this will leave some retries after a few seconds blanking
  }
  if (verbose) set_tone(0);  
  if (lasthighcount*DCF_SAMPLE_DELAY_MS>1500) { //start bit found 
     if (lowcount*DCF_SAMPLE_DELAY_MS<150) {
       return 2; //startbit and 0
     } else {
       return 3; //startbit and 1
     }
  }
  if (lowcount*DCF_SAMPLE_DELAY_MS<150) {  //normal bit
    return 0; //short delay (should be 100ms) -> assume logical 0
  } else {
    return 1; //long delay (should be 200ms) -> assume logical 1
  }
}


void clock_set_time_dcf(uint8_t verbose) {  //this reads the dcf signal, decodes it and sets the correct time to the clock; alternative way: build dcf structure and fill in bits
  uint8_t retry,bitcount,tmp,bit,p1,p2,hr,min,lasthr,lastmin;
  dcf_state=DCF_STATE_START;
  retry=0; hr=0; min=0; p1=0; p2=0; bitcount=0; tmp=0; bit=0;
  lasthr=255; lastmin=255; //not 0 because without signal, the time might decode to zero
  
  if (verbose) {
    out_morse("QTR? ");
  }
  while (retry<DCF_MAX_RETRIES) {
      if (state_changed) dcf_state=DCF_STATE_DONE; //this has been set in the interrupt routine already, but may have changed
      if (dcf_state==DCF_STATE_WAIT||dcf_state==DCF_STATE_SKIP||dcf_state==DCF_STATE_GET_MIN||dcf_state==DCF_STATE_GET_HR) { //need next bit
          bit=dcf_get_next_bit(verbose);
	  bitcount++;
	  //error checking
	  if(bit==4) { //can't even get start of sequence, probably no signal
              if (verbose) { out_morse(" no signal "); }
	      hr=255; //this was a bad try - this asserts that at least 2 good tries will be needed to set the time
              dcf_state=DCF_STATE_RETRY; //retry...
           }
           if(bit==5) { //signal always high -> no information
               if (verbose) { out_morse("high signal "); }
	       hr=255; //this was a bad try - this asserts that at least 2 good tries will be needed to set the time
               dcf_state=DCF_STATE_RETRY;
           }
	   if ((dcf_state!=DCF_STATE_WAIT)&&(bit==2||bit==3)) {  //no startbit expected here
	       if (verbose) { out_morse(" unexpected startbit "); }
	       hr=255; //this was a bad try - this asserts that at least 2 good tries will be needed to set the time
	       dcf_state=DCF_STATE_RETRY;
	   }
      }	  
      switch (dcf_state) {
         case DCF_STATE_START: //start the first try
	     dcf_set_power(1);  //power on the dcf module --> don't forget to switch off afterwards!
	     bitcount=0;
	     dcf_state=DCF_STATE_WAIT;
	     break;  //break is important here, because one bit must be read in before continuing; but with break, everything is ok, because it leaves the switch block and dosn't check the next case
	 case DCF_STATE_RETRY: //start the next try
	     lasthr=hr; hr=0; lastmin=min; min=0; p1=0; p2=0;
	     retry++;
	      if (verbose) set_button_led(0);
	      bitcount=0;
	     dcf_state=DCF_STATE_WAIT;	 
	     break;
	 case DCF_STATE_WAIT:   //wait for second 0
	     if (bit==2||bit==3) { //startbit found
	         if (verbose) {set_button_led(1);} //start of minute
		 bitcount=0;
	         dcf_state=DCF_STATE_SKIP;
	     } else {  //prevent blocking due to rain....
	         bitcount++;
	         if (bitcount>60) {
		    if (verbose) out_morse("no startbit found");
		    dcf_state=DCF_STATE_RETRY;		 
		 }
	     }
	     break;
	 case DCF_STATE_SKIP:  //skip until bit 20; second starts with bit 21
	     if (bitcount==20) {
	        dcf_state=DCF_STATE_GET_MIN;
		tmp=1;
	     }
	     break;
	 case DCF_STATE_GET_MIN: //get minute
             if (bitcount<28) {
                p1+=bit;
                min+=tmp*bit;      
                tmp=tmp<<1; //tmp could be used in the for loop instead of j, but this is ok
                if (tmp==16) {  //follow BCD Code, not binary
		    tmp=10;
		}
	     }
	     if (bitcount==28) {
	        p1+=bit; //parity bit for minutes. even parity is correct
		tmp=1;
		dcf_state=DCF_STATE_GET_HR;
	     }
	     break;
	 case DCF_STATE_GET_HR:  //get hour
	     if (bitcount<35) {
                 p2+=bit;
                 hr+=tmp*bit;      
                 tmp=tmp<<1; //tmp could be used in the for loop instead of j, but this is ok
                 if (tmp==16) {  //follow BCD Code, not binary
                    tmp=10;
                 }
             }
	     if (bitcount==35) {
                p2+=bit; //parity bit for hours. even parity is correct      
	        if (verbose) {set_button_led(0);} //35 seconds passed, got all information
	        dcf_state=DCF_STATE_CHECK;
             }
	     break;
	 case DCF_STATE_CHECK:  //if time/parity is ok , set time, else retry
	     if (((lasthr+(lastmin+1)/60)%24==hr) && ((lastmin+1)%60==min)&&(p1%2==0)&&(p2%2==0)) { //if now is time of last try + 1 min and parity is even, then everything is ok
                dcf_set_power(0);
                reset_oscillator();
                set_time(lasthr,lastmin,35); //time is coded into 60 seconds -> coding of mins and hrs is finished at second 35 (including parity bit). min and hr is correct in 25 secs, so use lasthr, lastmin
                if (verbose) {
                   out_morse("time ok ");
	           out_morse_time();
                }
                dcf_state=DCF_STATE_DONE;
             }
	     else { 
	         dcf_state=DCF_STATE_RETRY;
	         if (verbose) { //time not ok -> complain (this messeage must not take longer than ~24 seconds!)
                     if (p1%2!=0||p2%2!=0) { //parity error
                         out_morse("parity");
                     } else if (retry>0) {
                         out_morse("time mismatch ");
                     }
                 }
	     }
	     break;
	 case DCF_STATE_DONE:
	     if (verbose) { set_button_led(0); }
	     dcf_set_power(0);
	     return;
         default: dcf_state=DCF_STATE_DONE;
	     break;
      } //end switch
  }  //end while
  //we only get here if the time was never ok
  dcf_set_power(0);
  if (verbose) {
    set_button_led(0);
    char outstr[30];
    sprintf(outstr,"bad signal after %d retries ",DCF_MAX_RETRIES); //defines don't get replaced inside strings
    out_morse(outstr);
  }
  return;
}

void post(void) { //Power On Self Test
  uint8_t i=0,j=0,k=0;
  for (i=0;i<24;i++) {
    for (j=0;j<60;j++) {
        reset_oscillator(); //this prevents a possible race condition which might occur if the 32kHz Oscillator goes from 32767 to 0 between set_time() and get_time()
        for (k=0;k<60;k++){
          set_time(i,j,k);
	  get_time();
	  if (i!=get_hr || j!=get_min || k!= get_sec) {
	    //try again
	    set_time(i,j,k);
	    get_time();
	    if  (i!=get_hr || j!=get_min || k!= get_sec) {  //must be an error
              char errormsg[30];
	      sprintf(errormsg,"post error set %d:%d:%d get %d:%d:%d",i,j,k,get_hr,get_min,get_sec);
	      out_morse(errormsg);
	    }
	 }
      }
    }
  }
  //test leds and speaker
  set_button_led(1);
  set_leds(32,64,0);
  set_tone(1);
  delay_ms(1000);
  set_button_led(0);
  set_leds_rst();
  set_tone(0);
  //post finished
  out_morse(" post done ");
}


//Signal can't be interrupted, Interrupt can

//Wakeup-signal?
SIGNAL(SIG_INTERRUPT0) {
   GICR&=~_BV(INT0); //disable wakeup interrupt
   MCUCR &= ~_BV(SE); //disable sleep mode
   state=STATE_WAKEUP;
   state_changed=1;
   dcf_state=DCF_STATE_DONE;
}

uint8_t button_down(void){  //high if button is down
  return ((PIND&_BV(PD3))==0);
}

//Button pressed?
SIGNAL(SIG_INTERRUPT1) {
  MCUCR&=~_BV(SE);
  button_down_time=0; button_up_time=0;
  set_button_led(1);
  while (button_up_time*BUTTON_DELAY_MS<50) { //Button needs to be continually up at least 50 ms to continue
      if (button_down()) {
          button_down_time++;
          button_up_time=0;
          delay_ms(BUTTON_DELAY_MS);
	  if (((state==STATE_WAKEUP||state==STATE_DOZE)&&(button_down_time*BUTTON_DELAY_MS>=2000)) ||  ((state==STATE_IDLE)&&(button_down_time*BUTTON_DELAY_MS>5000))) {
	      set_button_led(0); 
	  }
      } else {
          button_up_time++;
          delay_ms(BUTTON_DELAY_MS);
      }
  }
  
  set_button_led(0);  
  //state transition
  switch (state) {
      case STATE_IDLE:
         if (button_down_time*BUTTON_DELAY_MS<5000) {
	     state=STATE_SHOW_TIME;
	 } else {
	     state=STATE_SET_TIME_DCF_VERBOSE;
	 }
	 state_changed=1;
	 break;
      case STATE_WAKEUP:
         if(button_down_time*BUTTON_DELAY_MS<2000) {
	     state=STATE_DOZE;
	  } else {
	      state=STATE_WAKEUP_END;
	  }
	  state_changed=1;
	  break;
      case STATE_DOZE:
         if (button_down_time*BUTTON_DELAY_MS>=2000)  {
	     state=STATE_WAKEUP_END;
	     state_changed=1;
	 } else { //show time
	   get_time();
	   set_leds(get_hr,get_min,200);
	   delay_ms(5000);
	   set_leds_rst();
	 }
	 break;
      case STATE_WAKEUP_END: //no change
          break;
      case STATE_SHOW_TIME:  //no change
          break;
      case STATE_SET_TIME_DCF: //don't interrupt
          dcf_state=DCF_STATE_RETRY; //probably missed a bit or two, so start over
          break;
      case STATE_SET_TIME_DCF_VERBOSE:  //stop it
          state=STATE_IDLE;
          dcf_state=DCF_STATE_DONE;
	  state_changed=1;
	  break;  
  }
}

int main(void) {
  uint32_t tmp;
  uint8_t wakeup_hr, wakeup_min;
  state_changed=0;  //don't let routines think they have to get back to main
  //initialize output and input pins
  initialize();
  //disable blue leds
  set_leds_rst();
  //power on self test
  post();
  //get time from dcf 
  clock_set_time_dcf(1);
  //globally enable interrupts
  sei();
  //set state to default (go to sleep)
  state=STATE_IDLE;
  while(1) {
    state_changed=0;
    switch (state) {
      case STATE_IDLE:  //go to power down mode	  
	  //dcf_set_power(0);
	  //set_tone(0);
	  //set_button_led(0);
	  //set_leds_rst();
	  sleep();
          break;
      case STATE_WAKEUP:  //play wakeup messages until at least 2 min has passed
          srand(button_down_time);
	  set_button_led(1);
	  get_time();
	  wakeup_hr=get_hr; wakeup_min=get_min;
	  while (!state_changed) {
	      tmp=rand();
	      srand(tmp);
	      out_morse_wakeup_message((uint8_t)tmp);
	      get_time();
	      if (get_hr>wakeup_hr||get_min>wakeup_min+1||(wakeup_hr==23&&get_hr!=23)) { //obviously noone here -> stop wakeup
	          if (!state_changed) { //button may have been pressed in between
		      set_button_led(0);
		      state=STATE_WAKEUP_END;
		      state_changed=1;
		  }
	      }
	  }
          break;
      case STATE_DOZE:  //sleep some time and go to wakeup again
          get_time();
	  set_leds(get_hr,get_min,200);
	  delay_ms(5000);
	  set_leds_rst();
          for (tmp=0;tmp<DOZE_TIME_SEC;tmp++) {
	    delay_ms(1000);
	    if (state_changed) break;
	  }
	  if (!state_changed) state=STATE_WAKEUP;  //need another test because if the break above got active, it only exited the loop
          break;
      case STATE_WAKEUP_END: //confirm, set time according to DCF and go to sleep
          out_morse("k");
	  state=STATE_SET_TIME_DCF;
	  break;
      case STATE_SHOW_TIME:
          get_time();
          set_leds(get_hr,get_min,200);
	  delay_ms(5000);
          set_leds_rst();
	  state=STATE_IDLE;
	  break;
      case STATE_SET_TIME_DCF:
          clock_set_time_dcf(0);
	  state=STATE_IDLE;
          break;
      case STATE_SET_TIME_DCF_VERBOSE:
          clock_set_time_dcf(1);
	  state=STATE_IDLE;
	  break;
      default: state=STATE_IDLE;      
    }
  }
}
