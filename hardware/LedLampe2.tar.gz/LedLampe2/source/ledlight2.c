/*
LedLight2 Source Code
Code teilweise geklaut von Guido Socher
*/

/*
notes
In Pins intern Pull-Up -> aussen kein R n�tig
Interrupt -> nur Level Interrupt kann AVR aus Power Down Mode wecken
*/

/*
modes

0: Power Down
1: Alle Leds sehr schwach
2: 3 Leds
3: Alle Leds konstantstrom
4: gr�ne Led schwach
5: gr�ne Led stark
6: Blink Mode
7: Morse Code: andreas m�ller  2004

*/

/*
Pins

PD2  Interrupt 0 -> Push Button
PD3  Interrupt 1 -> Toggle Button

PD4 Power Waste Pin

PD0 Gruene Led

PB0 Led in Mitte
PD6 Led in Mitte
PD7 Led in Mitte

Leds aussen
PB1
PB2
PB3
PB4
PB5
PC0
PC1
PC2
PC3
PC4
PC5
PD1

PD5 externe Spannung
*/


#include <avr/io.h>
#include <avr/interrupt.h>
/*#include <avr/stdlib.h>*/
#include <avr/signal.h>

/* defines for future compatibility */
#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif

#define G_ON_TIME 75
#define G_OFF_TIME 150
#define W_ON_TIME_SHORT 10
#define W_OFF_TIME_SHORT 90
#define W_ON_TIME 200
#define W_OFF_TIME 200
#define ON_WAITTIME 10
#define ON_OFFTIMEUS 10
#define BLINK_ON_TIME 50
#define BLINK_OFF_TIME 300
#define MORSE_DOT_TIME 100
#define MSG_LEN 71

#define ANZ_MODES 8
#define DEBOUNCETIME 30
#define DEBOUNCETIMEMS 20
#define POWER_WASTE_TIME 1800

void set_ext_power(int state);

static unsigned char mode;
static unsigned char lastmode;
static unsigned char gotonextmode=0;
static unsigned char was_off;
static unsigned int debounce=DEBOUNCETIME;  //Interrupt1 nur aktiv wenn debounce noch maximal ist; bei debounce==0 : mode=0;

void sleep(void) {
  //wichtig: Sleep Mode != Output Tristated...
  was_off=1;
  set_ext_power(0);
  sbi(MCUCR,SE); //enable Sleep Mode
  sbi(MCUCR,SM); //SM=1->Power Down Mode (sont Idle, braucht mehr Strom);
  asm("SLEEP");
  //__asm__("sleep"); geht auch...
}

void delay_ms(unsigned short ms)
{
	unsigned short outer1, outer2;
     	while (ms) {
		outer1 = 100;
		while (outer1) {
			outer2=300;
			while (outer2) {
				outer2--;
			}
			outer1--;
		}
		ms--;
	}
}

void delay_us(unsigned int us)
{
    while ( us ) us--;
}

void waste_power(void) { //entl�dt die Batterie ein wenig, damit sie nicht grad bei 4.5 V ist
  sbi(DDRD,PD4); //Pin enable
  cbi(PORTD,PD4);  //Power on
  unsigned short i;
  for (i=POWER_WASTE_TIME;i>0;i--){
     delay_ms(1000);
  }
  sbi(PORTD,PD4); //Power off
  //cbi(DDRD,PD4); //Pin disable

}

void no_waste_power(void) {
  sbi(DDRD,PD4); //Pin enable
  sbi(PORTD,PD4); //Power off
}

void nextmode(void) {
  mode++;
  if (mode>=ANZ_MODES) {mode=0;}
  lastmode=mode;
}

void white_on(void) {
/*Output to 0V, Leds enabled*/
  cbi(PORTB,PB0);
  cbi(PORTB,PB1);
  cbi(PORTB,PB2);
  cbi(PORTB,PB3);
  cbi(PORTB,PB4);
  cbi(PORTB,PB5);
  cbi(PORTC,PC0);
  cbi(PORTC,PC1);
  cbi(PORTC,PC2);
  cbi(PORTC,PC3);
  cbi(PORTC,PC4);
  cbi(PORTC,PC5);
  cbi(PORTD,PD1);
  cbi(PORTD,PD6);
  cbi(PORTD,PD7);
}

void white_off(void) {
/*Output to VCC, Leds disabled*/
  sbi(PORTB,PB0);
  sbi(PORTB,PB1);
  sbi(PORTB,PB2);
  sbi(PORTB,PB3);
  sbi(PORTB,PB4);
  sbi(PORTB,PB5);
  sbi(PORTC,PC0);
  sbi(PORTC,PC1);
  sbi(PORTC,PC2);
  sbi(PORTC,PC3);
  sbi(PORTC,PC4);
  sbi(PORTC,PC5);
  sbi(PORTD,PD1);
  sbi(PORTD,PD6);
  sbi(PORTD,PD7);
}

void _3_on(void){
  cbi(PORTB,PB0);
  cbi(PORTD,PD6);
  cbi(PORTD,PD7);
}

void _3_off(void) {
  sbi(PORTB,PB0);
  sbi(PORTD,PD6);
  sbi(PORTD,PD7);
}

void green_on(void) {
  cbi(PORTD,PD0);
}

void green_off(void) {
  sbi(PORTD,PD0);
}

void all_on(void) {
  white_on();
  green_on();
}

void all_off(void) {
  white_off();
  green_off();
}

/*
Morse Code
delays normal: dottime=1, dashtime=space between letters=3, space between words=7
here: dot=1 dash=5 words=12
*/

void m_on(int i) {
  unsigned short j;
  unsigned short max=500*i;
  for (j=0;j<max;j++){
    white_on();
    delay_us(MORSE_DOT_TIME);
    white_off();
    delay_us(MORSE_DOT_TIME);
  }
}

void m_off(int i) {
  white_off();
  delay_ms(i*MORSE_DOT_TIME);
}

void m_dot(void) {
  m_on(1);
  m_off(1);
}

void m_dash(void) {
  m_on(5);
  m_off(1);
}



void morse(char msg[MSG_LEN]) {
  int i;
  for (i=0;i<MSG_LEN;i++) {
    if ((mode!=7)||(gotonextmode)) return;
    switch (msg[i]) {
       case '.': m_dot(); break;
       case '-': m_dash(); break;
       case ' ': m_off(5); break; //1 schon vorher...
       case '/': m_off(11); break; //1 schon vorher...
    }
  }
}

void set_ext_power(int state) {
  if (state==0) {
	sbi(PORTD,PD5);
  } else {
	cbi(PORTD,PD5);
  }
}

void all_enable(void) {
  sbi(DDRB,PB0);
  sbi(DDRB,PB1);
  sbi(DDRB,PB2);
  sbi(DDRB,PB3);
  sbi(DDRB,PB4);
  sbi(DDRB,PB5);
  sbi(DDRC,PC0);
  sbi(DDRC,PC1);
  sbi(DDRC,PC2);
  sbi(DDRC,PC3);
  sbi(DDRC,PC4);
  sbi(DDRC,PC5);
  sbi(DDRD,PD0);
  sbi(DDRD,PD1);
  sbi(DDRD,PD6);
  sbi(DDRD,PD7);
}

void all_disable(void) {
  cbi(DDRB,PB0);
  cbi(DDRB,PB1);
  cbi(DDRB,PB2);
  cbi(DDRB,PB3);
  cbi(DDRB,PB4);
  cbi(DDRB,PB5);
  cbi(DDRC,PC0);
  cbi(DDRC,PC1);
  cbi(DDRC,PC2);
  cbi(DDRC,PC3);
  cbi(DDRC,PC4);
  cbi(DDRC,PC5);
  cbi(DDRD,PD0);
  cbi(DDRD,PD1);
  cbi(DDRD,PD6);
  cbi(DDRD,PD7);
}

//SIGNAL kann nicht unterbrochen werden, INTERRUPT schon

/* Button 1 gedr�ckt? */
SIGNAL(SIG_INTERRUPT0) {
   white_on();
   green_off();
   mode=0;
   delay_ms(ON_WAITTIME);
   white_off();
   delay_us(ON_OFFTIMEUS);
}

/* Button 2 gedr�ckt? */
SIGNAL(SIG_INTERRUPT1) {
  if(was_off) {
    cbi(MCUCR,SE); //disable Sleep Mode
    mode=lastmode;
    if (mode==0) {gotonextmode=1;}
    debounce=DEBOUNCETIME;
    debounce--;  //damit nicht gleich noch in den n�chsten Modus gewechselt wird..
    was_off=0;
  }
 else {
    if (debounce==DEBOUNCETIME) {gotonextmode=1;}
    if (debounce>0) {
      debounce--;
    }
    else {
      all_off();
      gotonextmode=0;
      mode=0;
    }
  }
  delay_ms(DEBOUNCETIMEMS);
}

int main(void)
{
        //waste_power();  //damit die LEDs nicht den vollen 4.5V ausgesetzt werden. Interrupts sind noch nicht aktiv, man kann also nur warten
	no_waste_power();
        all_enable(); //nur falls das keinen Strom verbraucht... -> scheint ok
	all_off();
        mode=0;
	//enable PD5 (ext power) as output
	sbi(DDRD,PD5);
	//enable some pins as input
	cbi(DDRD,PD2);
	cbi(DDRD,PD3);
	//enable internal Pull-Up Resistors
	sbi(PORTD,PD2);
	sbi(PORTD,PD3);
	//Interrupts scharf machen
	sbi(GIMSK,INT0);
	sbi(GIMSK,INT1);
	//Interrupt bei Low-Level (kann als einziger MCU wecken) andere: Interrupt bei fallenden Flanken ISCx0 = 0 ISCx1= 1  f�r steigend: ISCx0 = 1 ISCx1= 1
	cbi(MCUCR,ISC00);
	cbi(MCUCR,ISC01);
	cbi(MCUCR,ISC10);
	cbi(MCUCR,ISC11);
	sei(); //globally enable Interrupts

        while (1) {
	   if (gotonextmode) {
	     nextmode();
	     gotonextmode=0;
	   }
           debounce=DEBOUNCETIME;
	   switch(mode) {
               case 0:
	         all_off();
		 sleep();
		 break;
	       case 1:
	        white_on();
		delay_us(W_ON_TIME_SHORT);
		white_off();
		delay_us(W_OFF_TIME_SHORT);
		break;
	       case 2:
                _3_on();
                delay_ms(ON_WAITTIME);
		break;
	      /*case 3:
	        white_on();
		delay_us(W_ON_TIME);
		white_off();
		delay_us(W_OFF_TIME);
		break;*/
	      case 3:
	        white_on();
		delay_ms(ON_WAITTIME);
		white_off();
		delay_us(ON_OFFTIMEUS);
		break;
              case 4:
                 white_off();
		 set_ext_power(1);
	         green_on();
		 delay_us(G_ON_TIME);
		 green_off();
		 delay_us(G_OFF_TIME);
		 break;
	      case 5:
		 set_ext_power(0);
	         green_on();
		 delay_ms(ON_WAITTIME);
		 break;
	      case 6:
	         all_on();
		 delay_ms(BLINK_ON_TIME);
		 all_off();
		 delay_ms(BLINK_OFF_TIME);
		 break;
	      case 7:
	         morse(".- -. -.. .-. . .- .../-- ..-- .-.. .-.. . .-./..--- ----- ----- ...../");
		 break;
	   }
        }
}
