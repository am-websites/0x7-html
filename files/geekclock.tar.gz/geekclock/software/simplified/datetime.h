#ifndef DATETIME_H
#define DATETIME_H

uint8_t days_of_month[12] = {31,28,31,30,31,30,31,31,30,31,30,31}; /* Gregorian calender */

extern uint8_t is_leap_year(uint16_t _year);

#endif
