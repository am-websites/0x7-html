#include <avr/io.h>
#include <stdint.h>

void initialise(void) { /* don't change stuff in this function unless you know what you're doing */
	/* pin configuration */
	/* bit n in register DDRX is high, if we want to use port PXn as output */ 
	/* example: DDRB=4 -> PB2 is output, PB0-1 and 3-7 are input pins */
	PORTC|=_BV(PC6);	/* enable internal pull-up for RESET pin (should be default, just to be sure..) */
	PORTD|=_BV(PD2);	/* enable internal pull-up for PD2 (where the button is connected) */
	DDRC=63;	/* configure pins PC0..PC5 as output; PC6 is reset, so no output there */
	PORTC=63;	/* voltage is high an PC0..PC5; as leds are connected to VCC, this means they will be off */

	/* to save power, we must enable the internal pull-up for unused pins (instead of leaving them floating) */
	PORTB=63; /* pull-up for PB0..PB5 */
	PORTD=255; /* pull-up for all pins */
	
	/* initialize timer1 */
	/*Bit	7	6	5	4	3	2	1	0
	--------===============================================================================
	TCR1A 	COM1A1	COM1A0	COM1B1	COM1B0	FOC1A	FOC1B	WGM11	WGM10
	TCR1B	ICNC1	ICES1	-	WGM13	WGM12	CS12	CS11	CS10
	TIMSK	OCIE2	TOIE2	TICIE1	OCIE1A	OCIE1B	TOIE1	-	TOIE0
	TIFR	OCF2	TOV2	ICF1	OCF1A	OCF1B	TOV1	-	TOV0

	WGM13..10 = 0100 -> Clear Timer on Compare (CTC), TOP in OCR1A or WGM13..10=1100 -> CTC, TOP in ICR1
	CS12..10 = 001 -> Clock from System Clock, no prescaling
	*/
	TCCR1A = 0;
	TCCR1B = _BV(WGM12)|_BV(CS10);
	OCR1A=32768;	/* 1 interrupt per 32768 cycles = 1 interrupt per second */
	TIMSK = _BV(OCIE1A);	/* output compare A match interrupt enable */

	/* interrupt setup */
	GICR|=_BV(INT0); /* enable INT0 */
	MCUCR|=_BV(ISC01); /* falling edge on INT0 (button down) generates an interrupt */

	/* disable unused peripherals to save power */
	ACSR=_BV(ACD); /* disable analog comparator */
	TWCR=0;ADCSRA=0;UCSRB=0;SPCR=0; /* disable TWI,UART,etc - should all be disabled by default */

}

/* low precision delay function using timer0 
 * (note: do not use timer0 with interrupts, as this might create race conditions with interrupts from timer1)
 **/
void delay_ms(uint16_t ms) {
	uint8_t ms8;
	TCCR0 = _BV(CS02); /* enable timer0; prescaler=256 */
	while (ms>=250) {
		TCNT0 = 0;
		while (TCNT0<32); 
		ms-=250; /* 32*256/32768Hz = 250ms */
	}
	TCCR0 = _BV(CS00); /* no prescaling */
	ms8 = (uint8_t)ms; /* 8bit type - easier guessing of the number of cycles */
	while (ms8) {
		TCNT0 = 0;
		while (TCNT0<26); /* just a guess; the outher while should use 32 cycles in total - about 1ms */
		ms8--;
	}
	TCCR0 = 0; /* disable timer0 */
}

/* check if the button is down (PD2 pulled to ground) */
uint8_t button_down(void) {
	return ((~PIND & _BV(PD2)) > 0);
}

/* set leds to value */
void set_leds(uint8_t value) { 
	/* invert value and output directly to PORTC (lower 6 bits) */
	PORTC=~(value&63); /* this changes the upper bits to one; if thats not ok, use something like PORTC|=(~value)&63;PORTC&=(~value)|(~63); */
}
