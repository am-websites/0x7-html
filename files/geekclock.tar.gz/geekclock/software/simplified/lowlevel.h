#ifndef LOWLEVEL_H
#define LOWLEVEL_H

extern void initialise(void);
extern void delay_ms(uint16_t ms);
extern uint8_t button_down(void);
extern void set_leds(uint8_t value);

#endif
