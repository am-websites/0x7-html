#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>


uint8_t button_pressed;

/* very low precision delay function 
 for 32kHhz crystal oscillator */
void delay_ms(uint16_t ms) {
	while (ms) {
		ms--;
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
	}
}

/* the push button is connected to PD2
   -> INT0 is called whenever it's pressed */
ISR(INT0_vect) { 
	button_pressed=1;	/* always try to keep code inside interrupt handlers short */
}

int main(void) {
	button_pressed = 0;
	
	/* pin configuration */
	PORTC|=_BV(PC6);	/* enable internal pull-up for RESET pin (should be default, just to be sure..) */
	PORTD|=_BV(PD2);	/* enable internal pull-up for PD2 (where the button is connected) */
	DDRC=63;	/* configure pins PC0..PC5 as output; PC6 is reset, so no output there */
	
	/* interrupt setup */
	GICR|=_BV(INT0); /* enable INT0 */
	MCUCR|=_BV(ISC01)|_BV(ISC00); /* rising edge generates an interrupt request */
	sei();		/* globally enable interrupts */
	
	while (!button_pressed) {
		PORTC=0;	/* 0V -> LEDs are on */
		delay_ms(500);
		PORTC=63; 	/* 5V -> LEDs are off */
		delay_ms(500);	
	}
	/* idle mode */
	DDRB=0;
	PORTB=255;
	DDRC=0;
	PORTC=255;
	DDRD=0;
	PORTD=255;
	ACSR=_BV(ACD);
	TWCR=0;ADCSRA=0;UCSRB=0;SPCR=0;
	set_sleep_mode(SLEEP_MODE_IDLE);
	sleep_mode();
	while (1) {

	}
}
