#include <avr/io.h>
#include <avr/interrupt.h>

uint8_t button_pressed;

/* very low precision delay function 
 for internal 1MHz RC oscillator */
void delay_ms(uint16_t ms) {
	uint8_t i;
	while (ms) {
		ms--;
		i=100;
		while (i) {
			asm("nop");
			asm("nop");
			asm("nop");
			asm("nop");
			asm("nop");
			asm("nop");
			asm("nop");
			i--;
		}
	}
}

/* the push button is connected to PD2
   -> INT0 is called whenever it's pressed */
ISR(INT0_vect) { 
	button_pressed=1;	/* always try to keep code inside interrupt handlers short */
}

int main(void) {
	button_pressed = 0;
	uint8_t i;
	
	/* pin configuration */
	PORTC|=_BV(PC6);	/* enable internal pull-up for RESET pin (should be default, just to be sure..) */
	PORTD|=_BV(PD2);	/* enable internal pull-up for PD2 (where the button is connected) */
	DDRC=63;	/* configure pins PC0..PC5 as output; PC6 is reset, so no output there */
	
	
	/* interrupt setup */
	GICR|=_BV(INT0); /* enable INT0 */
	MCUCR|=ISC01|ISC00; /* rising edge generates an interrupt request */
	sei();		/* globally enable interrupts */
	
	while (!button_pressed) {
		PORTC=0;	/* 0V -> LEDs are on */
		delay_ms(500);
		PORTC=63; 	/* 5V -> LEDs are off */
		delay_ms(500);	
	}
	while (1) {
		for (i=0;i<6;i++) {
			PORTC = 63 & ~(1<<i);
			delay_ms(200);
		}
	}
}
