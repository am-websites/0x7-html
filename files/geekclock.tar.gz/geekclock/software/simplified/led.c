#include <stdint.h>
#include <avr/io.h>
#include "lowlevel.h"

void blink_leds(uint8_t cycles) {
	while (cycles>0) {
		set_leds(63);
		delay_ms(250);
		set_leds(0);
		delay_ms(250);
		cycles--;
	}
}

void show_value(uint8_t value) {
	set_leds(value);
	delay_ms(1500);
	set_leds(0);
	delay_ms(300);
}

/* linear fading */
void show_value_with_special_effect1(uint8_t value) {
	uint8_t portcvalue = ~(value&63);
	uint8_t i,j,k;
	uint8_t max=20;
	for (i=0;i<=max;i++) {
		for (j=0;j<5;j++) {
			k=0;
			PORTC=portcvalue;
			while (k<i)
				k++;
			PORTC=127;
			while (k<max)
				k++;
		}
	}
	for (i=max;i>0;i--) {
		for (j=0;j<5;j++) {
			k=0;
			PORTC=portcvalue;
			while (k<i)
				k++;
			PORTC=127;
			while (k<max)
				k++;
		}
	}
	set_leds(0);
	delay_ms(200);
}

/* nonlinear fading */
void show_value_with_special_effect2(uint8_t value) {
	uint8_t portcvalue = ~(value&63);
	uint8_t i,j,k,jmax;
	uint8_t max=20;
	for (i=0;i<=max;i++) {
		jmax=15-i/4;
		for (j=0;j<jmax;j++) {
			k=0;
			PORTC=portcvalue;
			while (k<i)
				k++;
			PORTC=127;
			while (k<max)
				k++;
		}
	}
	for (i=max;i>0;i--) {
		jmax=15-i/4;
		for (j=0;j<jmax;j++) {
			k=0;
			PORTC=portcvalue;
			while (k<i)
				k++;
			PORTC=127;
			while (k<max)
				k++;
		}
	}
	set_leds(0);
	delay_ms(300);
}

/* count-up */
void show_value_with_special_effect3(uint8_t value) {
	uint8_t i;
	for (i=0;i<=value;i++) {
		set_leds(i);
		delay_ms(30);
	}
	delay_ms(1000);
	set_leds(0);
	delay_ms(200);
}

/* random blinking */
void show_value_with_special_effect4(uint8_t value) {
	uint8_t rand = TCNT1H;
	uint8_t i;
	for (i=0;i<20;i++) {
		set_leds(rand&63);
		delay_ms(100);
		rand*=7; 	/* cheap pseudo random number generator */
		rand+=TCNT1L;
		rand=~rand;
	}
	set_leds(value);
	delay_ms(1500);
	set_leds(0);
	delay_ms(200);
}

/* single LED slide-in  */
void show_value_with_special_effect5(uint8_t value) {
	int8_t i,j;
	uint8_t current=0;
	for (i=7;i>=0;i--) {
		if ((value&_BV(i))>0) {
			for (j=0;j<i;j++) {
				set_leds(current | _BV(j));
				delay_ms(50);
			}
			current|=_BV(i);
			set_leds(current);
			delay_ms(50);
		}
	}
	delay_ms(1500);
	set_leds(0);
	delay_ms(200);
}

/* wrapper function */
void show_value_with_special_effect(uint8_t value, uint8_t effect) {
	switch (effect) {
		case 1:
			show_value_with_special_effect1(value);
			break;
		case 2:
			show_value_with_special_effect2(value);
			break;
		case 3:
			show_value_with_special_effect3(value);
			break;
		case 4:
			show_value_with_special_effect4(value);
			break;
		case 5:
			show_value_with_special_effect5(value);
			break;
		default:
			show_value(value);
	}
}
