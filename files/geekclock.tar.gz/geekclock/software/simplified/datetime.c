#include <stdint.h>

/* determine whether a given year is a leap year (Gregorian calendar) */ 
uint8_t is_leap_year(uint16_t year) {
	if (year%4==0 && (year%100!=0 || year%400==0)) 
		return 1;
	else
		return 0;
}
