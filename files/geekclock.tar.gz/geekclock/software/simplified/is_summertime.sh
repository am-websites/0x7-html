#!/bin/sh

# may need adjustment to your system ...

if [ `date +%Z` = "CEST" ] 
then
	echo "summertime=1;"	
else
	echo "summertime=0;"
fi
