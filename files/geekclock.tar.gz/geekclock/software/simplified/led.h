#ifndef LED_H
#define LED_H

extern void blink_leds(uint8_t cycles); /* let the led's blink */
extern void show_value(uint8_t value); /* show a value in binary form on the leds */
extern void show_value_with_special_effect(uint8_t value, uint8_t effect); /* wrapper function to show a value with special effects */

#endif
