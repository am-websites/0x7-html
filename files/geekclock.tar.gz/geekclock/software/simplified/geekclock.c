/* geekclock.c - thinkgeek style led clock
 *
 * this is the code for the simplified geekclock, operating with a 32768 Hz crystal 
 * note that simplified only applies to the hardware, not the software
 *
 * by Andreas M�ller, 2007
 * use and distribute freely under GNU GPL conditions 
 *
 * v 0.4 20070610
 *
 * history
 *
 * 0.1 initial; code mostly from original geekclock
 * 0.2 power consumption lowered; special effects added
 * 0.3 year/month/day now known; automatic summer-/wintertime change
 * 0.4 new delay function; OneButtonInterface for time configuration; code split into multiple files
 **/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include "lowlevel.h"
#include "datetime.h"
#include "led.h"

uint8_t month,day,day_of_week,hour,minute,second,second_adjust_delay;
uint16_t year;
uint8_t button_pressed,summertime,auto_change_dst;

void show_time(void) {	
	uint8_t effect = 0;
	/* show_value(hour);
	show_value(minute);
	show_value(second); */
	/* use current clock count to create random effect (user presses button at random time) */
	switch (TCNT1L%4) {
		case 0:
			effect = 2;
			break;
		case 1:
			effect = 3;
			break;
		case 2:
			effect = 4;
			break;
		case 3:
			effect = 5;
			break;
	}
	/* show_value_with_special_effect(month,effect);
	show_value_with_special_effect(day,effect); */
	show_value_with_special_effect(hour,effect);
	show_value_with_special_effect(minute,effect);
	show_value_with_special_effect(second,effect);
}



/* nice one-button-interface to configure hours and minutes 
 * still in beta stage ... */
uint8_t configure_value(uint8_t init_value, uint8_t min, uint8_t max) {
	uint8_t value=init_value;
	TCNT1=0;
	second=0;
	button_pressed=0;
	while (second<1) { /* configure hour */
		if (!button_down()) {
			TCNT1=0;
			second=0;
			if (button_pressed) {
				value++;
				if (value==max)
					value=min;
				button_pressed=0;
			}
			set_leds(value);
			delay_ms(100);
			set_leds(0);
			delay_ms(100);
		}
	}
	blink_leds(3);
	return value;
}

void configure_time(void) {
	/* date may be wrong now; no longer change summer/winter time automatically */
	/* if you want to configure year/month/day instead, don't forget to adjust day_of_week and summertime (can be done without users help) */
	auto_change_dst=0; 
	/* configure hour and mintute */
	hour = configure_value(hour,0,24);
	minute = configure_value(minute,0,60);
}


/*
 * each second, one interrupt is generated
 *
 * this function must not use more than one second to execute (i.e. 32768 operations)
 * while we're in here, button presses will be ignored, so it's a good idea to use only a small fraction of a second
 */
ISR(TIMER1_COMPA_vect) { /* catch timer event */ /* TODO code for summer-/wintertime change has never actually been tested */
	if (second_adjust_delay>0) {
 		second_adjust_delay--;
	} else { /* increase time by one second */
		second++;
		if (second==60) { /* next minute */
			minute++; 
			second=0;
			if (minute==60) { /* next hour */
				hour++;
				minute=0;
				if (hour==24) { /* new day */
					hour=0;
					/* software calibration:
					 * if the clock is x seconds too fast, set second_adjust_delay=x here,
					 * if it's x seconds too slow, set second=x */
					/*second=7*/
					/* update date */
					if (day_of_week==7)
						day_of_week=1;
					else 
						day_of_week++;
					if (month==2 && day==28) { /* no month++ if we have a leap year */
						if (is_leap_year(year)) {
							day++;
						} else {
							month++;
							day=1;
						}
					} else if (day>=days_of_month[month-1]) { /* new month */ /* it's important to use >= here, because of Feb 29 */
						if (month==12) { /* new year */
							month=1;
							year++;
						} else {
							month++;
						}
						day=1;
					} else {
						day++;
					}
				}
				if (hour==2) { /* check if there is a winter -> summertime change */
					if (month==3 && day_of_week==7 && day>24) { /* last sunday of march */
						if (summertime==0 && auto_change_dst) { /* still wintertime and auto_change wanted */
							summertime = 1;
							hour = 3;
						}
					}
				}
				if (hour==3) { /* check if there is a summer -> wintertime change */
					if (month==10 && day_of_week==7 && day>24) { /* last sunday of octobre */
						if (summertime==1 && auto_change_dst) { /* still summertime and auto_change wanted */
							summertime = 0;
							hour = 2;
						}
					}
				}
			}
		}
	}
	/* for alarm at 6:30 */
	/* note: only change some switch variable here and do the action in the main routine */
	/* if (hour==6&&minute==30) { wakeup=1; } */
}

/* the push button is connected to PD2
   -> INT0 is called whenever it's pressed */
ISR(INT0_vect) { 
	button_pressed=1;	/* always try to keep code inside interrupt handlers short */
}

int main(void) {
	/* initialise: set up the timer and initialise ports */
	initialise();
	button_pressed = 0;
	/* starting time is current time */
	#include "currenttime.c"
	/* automatically change daylight saving time (summer-/wintertime) */
	auto_change_dst=1;
	/* globally enable interrupts */
	sei(); 
	/* show that the program has started */
	blink_leds(3);
	/* main loop */
	while(1) {
		if (button_pressed) { /* button was pressed -> display the time */
			show_time();
			if (button_down())  /* button still (or again) pressed -> configure the time */
				configure_time();	
			button_pressed=0;
		}
		set_sleep_mode(SLEEP_MODE_IDLE); /* the life of a clock is rather boring; most of the time it's just waiting */
		sleep_mode();
	}
}

