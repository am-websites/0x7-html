#include <avr/io.h>

/* low precision delay function */
void delay_ms(uint16_t ms) {
	uint16_t i; 
	while (ms) {
		ms--;
		for (i=0;i<200;i++) {
			asm("nop");
		}
	}
}


int main(void) {
	uint8_t i;
	
	DDRC=63;	/* PC6 is reset, so no output there */
	DDRD=255;


	while (1) {
		/* direcly output binary numbers to PORTC */
		for (i=0;i<64;i++) {	
			PORTC=63-i;
			delay_ms(100);
		}
		/* turn on one led at once */
		for (i=0;i<8;i++) {
			/* note: _BV(i) is defined as (1<<i) somewhere in avr-libc
			 * you can use it for better readability, but otherwise it's equivalent to (1<<i) */
			PORTD=~_BV(i); /* note: the value is inverted because the led is on if the port is low */
			delay_ms(100);
		}

	}
}
