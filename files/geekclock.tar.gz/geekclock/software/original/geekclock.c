/* geekclock.c - thinkgeek style led clock */
/* by Andreas M�ller */
/* use and distribute freely under GNU GPL conditions */

#include <avr/io.h>
#include <avr/interrupt.h>


#define SEC_BIT0_PORT PORTB
#define SEC_BIT0_PIN PB0
#define SEC_BIT1_PORT PORTB
#define SEC_BIT1_PIN PB1
#define SEC_BIT2_PORT PORTB
#define SEC_BIT2_PIN PB2
#define SEC_BIT3_PORT PORTD
#define SEC_BIT3_PIN PD5
#define SEC_BIT4_PORT PORTD
#define SEC_BIT4_PIN PD6
#define SEC_BIT5_PORT PORTD
#define SEC_BIT5_PIN PD7


volatile uint8_t hour,minute,second,second_adjust_delay;
volatile uint8_t *sec_bit_leds_ports[6]={&SEC_BIT0_PORT,&SEC_BIT1_PORT,&SEC_BIT2_PORT,&SEC_BIT3_PORT,&SEC_BIT4_PORT,&SEC_BIT5_PORT};
volatile uint8_t sec_bit_leds_pins[6]={SEC_BIT0_PIN,SEC_BIT1_PIN,SEC_BIT2_PIN,SEC_BIT3_PIN,SEC_BIT4_PIN,SEC_BIT5_PIN};

/* high precision delay for 4MHz */
/*
 * delays for ms milliseconds + about 4 microseconds
 * 
 * push, pop: 2 instructions
 * breq,brne: 1/2
 * cp: 1
 * dec: 1
 * ldi: 1
*/
void delay_ms( uint8_t ms) {
asm volatile("\
push r0\n\
push r16\n\
push r17\n\
push r18\n\
mov r16,%0\n\
clr r0\n\
cp r0,r16\n\
breq end\n\
loop:\n\
	ldi r17,85\n\
	loop2:\n\
		ldi r18,10\n\
		loop3:\n\
			dec r18\n\
			cp r18,r0\n\
			brne loop3\n\
		nop\n\
		nop\n\
		nop\n\
		dec r17\n\
		cp r17,r0\n\
		brne loop2\n\
	dec r16\n\
	nop\n\
	cp r0,r16\n\
	brne loop\n\
end:\n\
pop r18\n\
pop r17\n\
pop r16\n\
pop r0\n"
	:  : "d" (ms) );
}

void delay_ms_long (uint16_t ms) {
	while (ms>255) {
		delay_ms(255);
		ms-=255;
	}
	delay_ms(ms);
}

void initialize(void) { /* don't change stuff in this function unless you know what you're doing */
	/* initialize ports */
	/* bit n in register DDRX is high, if we want to use port PXn as output 
	 * example: DDRB=4 -> PB2 is output, PB0-1 and 3-7 are input pins */
	DDRB=7;		/* port B: PB0, PB1, PB2 is output; PB3-5 is LPT interface and PB6-7 is crystal, so don't use these as output! */
	DDRC=63;	/* port C: PC0-PC5 is output; PC6 is reset (DON'T set the fuse to use it as regular I/O) */
	DDRD=255; 	/* port D: all pins are output */
	/* bit n in register PORTX specifies whether PXn is high (=VCC=5V) or low (=GND=0V) 
	 * example: PORTC=10 -> PC0,PC2,PC4-PC6 are low (0V), but PC1 and PC3 are high (5V)
	 * we set all output ports high; as leds are connected to VCC, this means they will be off */
	PORTB=7;
	PORTC=63;
	PORTD=255;
	/* initialize timer */
	/*Bit	7	6	5	4	3	2	1	0
	--------===============================================================================
	TCR1A 	COM1A1	COM1A0	COM1B1	COM1B0	FOC1A	FOC1B	WGM11	WGM10
	TCR1B	ICNC1	ICES1	-	WGM13	WGM12	CS12	CS11	CS10
	TIMSK	OCIE2	TOIE2	TICIE1	OCIE1A	OCIE1B	TOIE1	-	TOIE0
	TIFR	OCF2	TOV2	ICF1	OCF1A	OCF1B	TOV1	-	TOV0

	WGM13..10 = 0100 -> Clear Timer on Compare (CTC), TOP in OCR1A or WGM13..10=1100 -> CTC, TOP in ICR1
	CS12..10 = 100 -> Clock from System Clock, prescaled by 256
	*/
	TCCR1A = 0;
	TCCR1B = _BV(3)|_BV(2);
	OCR1A=15625;	/* output compare = 15625, because 4MHz / 256 (prescaler) = 15625 -> 1 Interrupt per second */
	TIMSK = _BV(4);	/* output compare A match interrupt enable */
}



/* set leds to display current hr,min,sec on the leds 
 *
 * expects hr<24,min<60,sec<60 */
void set_time_leds(uint8_t hr,uint8_t min, uint8_t sec) { 
	uint8_t i;
	/* invert hour and minute bitwise and output directly to PORTD and PORTC */
	PORTD=~hr|(PORTD&224);
	PORTC=~min;
	/* the second leds are distributed among different ports to the remaining pins - a little more work is required */
	for (i=0;i<6;i++) {
		if ((sec & (1<<i)) > 0) {
			*(sec_bit_leds_ports[i])&=~_BV(sec_bit_leds_pins[i]);
		} else {
			*(sec_bit_leds_ports[i])|=_BV(sec_bit_leds_pins[i]);
		}
	}

}


/*
 * each second, one interrupt is generated
 *
 * the code in this function should not use more than one second to execute
 */
ISR(TIMER1_COMPA_vect) { /* catch timer event */	
	if (second_adjust_delay>0) {
 		second_adjust_delay--;
	} else { /* increase time by one second */
		second++;
		if (second==60) { /* next minute */
			minute++; 
			second=0;
			if (minute==60) { /* next hour */
				hour++;
				minute=0;
				if (hour==24) {
					hour=0;
					/* if the clock is x seconds too fast, set second_adjust_delay=x here,
					 * if it's x seconds too slow, set second=x */
					
				}

			}
		}
	}
	/* set the leds to the current time */
	set_time_leds(hour,minute,second);
	/* for alarm at 6:30 */
	/* if (hour==6&&minute==30) { do_something(); } */
}

int main(void) {
	/* initialize: set up the timer and initialise ports */
	initialize();
	/* time at startup is 12:30 */
	/* hour=12; minute=30; second=0; */
	#include "currenttime.h"
	/* show the time */
	set_time_leds(hour,minute,second);
	/* globally enable interrupts */
	sei(); 
	/* do nothing loop - all work is done during the interrupt */
	while(1) {
		/* to dim the leds (eg at night), use something like */
		/*
		set_time_leds(hour,minute,second);
		delay_ms(5);
		set_time_leds(0,0,0);
		delay_ms(5);
		*/
		/* with a little more code, you can use time dependent light intensity or do other funny stuff */
	}
}
